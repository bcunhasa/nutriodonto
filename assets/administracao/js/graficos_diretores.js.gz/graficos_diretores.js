// Funções para criação de gráficos

document.addEventListener("DOMContentLoaded", function() {
    criaGraficoQuestao("#questao1", carregaDados("#questao1"));
    criaGraficoQuestao("#questao2", carregaDados("#questao2"));
    criaGraficoQuestao("#questao3", carregaDados("#questao3"));
    criaGraficoQuestao("#questao4", carregaDados("#questao4"));
    criaGraficoQuestao("#questao5", carregaDados("#questao5"));
    criaGraficoQuestao("#questao6", carregaDados("#questao6"));
    criaGraficoQuestao("#questao7", carregaDados("#questao7"));
    criaGraficoQuestao("#questao8", carregaDados("#questao8"));
    criaGraficoQuestao("#questao9", carregaDados("#questao9"));
    criaGraficoQuestao("#questao10", carregaDados("#questao10"));
    criaGraficoQuestao("#questao11", carregaDados("#questao11"));
    criaGraficoQuestao("#questao12", carregaDados("#questao12"));
    criaGraficoQuestao("#questao13", carregaDados("#questao13"));
    criaGraficoQuestao("#questao14", carregaDados("#questao14"));
    criaGraficoQuestao("#questao15", carregaDados("#questao15"));
    criaGraficoQuestao("#questao16", carregaDados("#questao16"));
    criaGraficoQuestao("#questao17", carregaDados("#questao17"));
    criaGraficoQuestao("#questao18", carregaDados("#questao18"));
    criaGraficoQuestao("#questao19", carregaDados("#questao19"));
    criaGraficoQuestao("#questao20", carregaDados("#questao20"));
    criaGraficoQuestao("#questao21", carregaDados("#questao21"));
    criaGraficoQuestao("#questao22", carregaDados("#questao22"));
    criaGraficoQuestao("#questao23", carregaDados("#questao23"));
    criaGraficoQuestao("#questao24", carregaDados("#questao24"));
    criaGraficoQuestao("#questao25", carregaDados("#questao25"));
    criaGraficoQuestao("#questao26", carregaDados("#questao26"));
    criaGraficoQuestao("#questao27", carregaDados("#questao27"));
    criaGraficoQuestao("#questao28", carregaDados("#questao28"));
    criaGraficoQuestao("#questao29", carregaDados("#questao29"));
    criaGraficoQuestao("#questao30", carregaDados("#questao30"));
    criaGraficoQuestao("#questao31", carregaDados("#questao31"));
    criaGraficoQuestao("#questao32", carregaDados("#questao32"));
    criaGraficoQuestao("#questao33", carregaDados("#questao33"));
    criaGraficoQuestao("#questao34", carregaDados("#questao34"));
    criaGraficoQuestao("#questao35", carregaDados("#questao35"));
    criaGraficoQuestao("#questao36", carregaDados("#questao36"));
    criaGraficoQuestao("#questao37", carregaDados("#questao37"));
    criaGraficoQuestao("#questao38", carregaDados("#questao38"));
    criaGraficoQuestao("#questao39", carregaDados("#questao39"));
    criaGraficoQuestao("#questao40", carregaDados("#questao40"));
    criaGraficoQuestao("#questao41", carregaDados("#questao41"));
    criaGraficoQuestao("#questao42", carregaDados("#questao42"));
    criaGraficoQuestao("#questao43", carregaDados("#questao43"));
    criaGraficoQuestao("#questao44", carregaDados("#questao44"));
    criaGraficoQuestao("#questao45", carregaDados("#questao45"));
    criaGraficoQuestao("#questao46", carregaDados("#questao46"));
    criaGraficoQuestao("#questao47", carregaDados("#questao47"));
    criaGraficoQuestao("#questao48", carregaDados("#questao48"));
    criaGraficoQuestao("#questao49", carregaDados("#questao49"));
    criaGraficoQuestao("#questao50", carregaDados("#questao50"));
    criaGraficoQuestao("#questao51", carregaDados("#questao51"));
    criaGraficoQuestao("#questao52", carregaDados("#questao52"));
    criaGraficoQuestao("#questao53", carregaDados("#questao53"));
    criaGraficoQuestao("#questao54", carregaDados("#questao54"));
    criaGraficoQuestao("#questao55", carregaDados("#questao55"));
    criaGraficoQuestao("#questao56", carregaDados("#questao56"));
    criaGraficoQuestao("#questao57", carregaDados("#questao57"));
    criaGraficoQuestao("#questao58", carregaDados("#questao58"));
    criaGraficoQuestao("#questao59", carregaDados("#questao59"));
    criaGraficoQuestao("#questao60", carregaDados("#questao60"));
    criaGraficoQuestao("#questao61", carregaDados("#questao61"));
    criaGraficoQuestao("#questao62", carregaDados("#questao62"));
    criaGraficoQuestao("#questao63", carregaDados("#questao63"));
    criaGraficoQuestao("#questao64", carregaDados("#questao64"));
    criaGraficoQuestao("#questao65", carregaDados("#questao65"));
    criaGraficoQuestao("#questao66", carregaDados("#questao66"));
    criaGraficoQuestao("#questao67", carregaDados("#questao67"));
    criaGraficoQuestao("#questao68", carregaDados("#questao68"));
    criaGraficoQuestao("#questao69", carregaDados("#questao69"));
    criaGraficoQuestao("#questao70", carregaDados("#questao70"));
    criaGraficoQuestao("#questao71", carregaDados("#questao71"));
    criaGraficoQuestao("#questao72", carregaDados("#questao72"));
    criaGraficoQuestao("#questao73", carregaDados("#questao73"));
    criaGraficoQuestao("#questao74", carregaDados("#questao74"));
    criaGraficoQuestao("#questao75", carregaDados("#questao75"));
    criaGraficoQuestao("#questao76", carregaDados("#questao76"));
    criaGraficoQuestao("#questao77", carregaDados("#questao77"));
    criaGraficoQuestao("#questao78", carregaDados("#questao78"));
    criaGraficoQuestao("#questao79", carregaDados("#questao79"));
    criaGraficoQuestao("#questao80", carregaDados("#questao80"));
    criaGraficoQuestao("#questao81", carregaDados("#questao81"));
    criaGraficoQuestao("#questao82", carregaDados("#questao82"));
    criaGraficoQuestao("#questao83", carregaDados("#questao83"));
    criaGraficoQuestao("#questao84", carregaDados("#questao84"));
});

function criaGraficoQuestao(questao, dados) {
    var data = dados;
    
    $.plot($(questao), data, { 
        series: {
            pie: {
                show: true,
                radius: 1,
                label: {
                    show: true,
                    radius: 0.9,
                    formatter: function (label, series) {
                        return '<div class="flot-pie-label">' + Math.round(series.percent) +'% (' + series.data[0][1] + ')</div>';
                    },
                    background: { 
                        opacity: 0.5,
                        color: '#000000'
                    }
                }
            }
        },
        grid: {
            hoverable: true
        },
        tooltip: true,
        tooltipOpts: {
            content: "%s: %p.0% (%y.0)",
        },
    });
}

function carregaDados(questao) {
    if (questao == "#questao1") {
        return [
            { label: "Manhã", data: questao_1[0] },
            { label: "Intermediário", data: questao_1[1] },
            { label: "Tarde", data: questao_1[2] },
            { label: "Noite", data: questao_1[3] },
            { label: "Sem resposta", data: questao_1[4] },
        ];
    } else if (questao == "#questao2") {
        return [
            { label: "Sim", data: questao_2[0] },
            { label: "Não", data: questao_2[1] },
            { label: "Sem resposta", data: questao_2[2] },
        ];
    } else if (questao == "#questao3") {
        return [
            { label: "Educação Infantil (creche, pré-escola)", data: questao_3[0] },
            { label: "Ensino Fundamental (8 anos, 9 anos)", data: questao_3[1] },
            { label: "Ensino Médio (médio, integrado, normal/magistério, educação profissional)", data: questao_3[2] },
            { label: "Educação de Jovens e Adultos (fundamental, projovem urbano, médio)", data: questao_3[3] },
            { label: "Sem resposta", data: questao_3[4] },
        ];
    } else if (questao == "#questao4") {
        return [
            { label: "Até 50 alunos", data: questao_4[0] },
            { label: "De 51 a 100 alunos", data: questao_4[1] },
            { label: "De 101 a 200 alunos", data: questao_4[2] },
            { label: "De 201 a 500 alunos", data: questao_4[3] },
            { label: "De 501 a 1.000 alunos", data: questao_4[4] },
            { label: "Mais de 1.000 alunos", data: questao_4[5] },
            { label: "Sem resposta", data: questao_4[6] },
        ];
    } else if (questao == "#questao5") {
        return [
            { label: "Até 10 salas", data: questao_5[0] },
            { label: "De 11 a 20 salas", data: questao_5[1] },
            { label: "De 21 a 30 salas", data: questao_5[2] },
            { label: "De 31 a 40 salas", data: questao_5[3] },
            { label: "De 41 a 50 salas", data: questao_5[4] },
            { label: "Mais de 50 salas", data: questao_5[5] },
            { label: "Sem resposta", data: questao_5[6] },
        ];
    } else if (questao == "#questao6") {
        return [
            { label: "Sim", data: questao_6[0] },
            { label: "Não está em condições de uso", data: questao_6[1] },
            { label: "Não tem biblioteca", data: questao_6[2] },
            { label: "Sem resposta", data: questao_6[3] },
        ];
    } else if (questao == "#questao7") {
        return [
            { label: "Sim", data: questao_7[0] },
            { label: "Não está em condições de uso", data: questao_7[1] },
            { label: "Não tem sala ou laboratório de informática", data: questao_7[2] },
            { label: "Sem resposta", data: questao_7[3] },
        ];
    } else if (questao == "#questao8") {
        return [
            { label: "Não existem computadores em condições de uso para os alunos", data: questao_8[0] },
            { label: "Até 10 computadores", data: questao_8[1] },
            { label: "De 11 a 20 computadores", data: questao_8[2] },
            { label: "De 21 a 30 computadores", data: questao_8[3] },
            { label: "De 31 a 40 computadores", data: questao_8[4] },
            { label: "De 41 a 50 computadores", data: questao_8[5] },
            { label: "Mais de 50 computadores", data: questao_8[6] },
            { label: "Sem resposta", data: questao_8[7] },
        ];
    } else if (questao == "#questao9") {
        return [
            { label: "Sim", data: questao_9[0] },
            { label: "Não", data: questao_9[1] },
            { label: "Sem resposta", data: questao_9[2] },
        ];
    } else if (questao == "#questao10") {
        return [
            { label: "Sim", data: questao_10[0] },
            { label: "Não está em condições de uso", data: questao_10[1] },
            { label: "Não tem sala de recursos de mídia/comunicação", data: questao_10[2] },
            { label: "Sem resposta", data: questao_10[3] },
        ];
    } else if (questao == "#questao11") {
        return [
            { label: "Sim", data: questao_11[0] },
            { label: "Não", data: questao_11[1] },
            { label: "Sem resposta", data: questao_11[2] },
        ];
    } else if (questao == "#questao12") {
        return [
            { label: "Não se reúne com frequência", data: questao_12[0] },
            { label: "1 a 3 vezes por ano", data: questao_12[1] },
            { label: "4 a 6 vezes por ano", data: questao_12[2] },
            { label: "7 a 9 vezes por ano", data: questao_12[3] },
            { label: "10 a 12 vezes por ano", data: questao_12[4] },
            { label: "Mais de 12 vezes por ano", data: questao_12[5] },
            { label: "Sem resposta", data: questao_12[6] },
        ];
    } else if (questao == "#questao13") {
        return [
            { label: "Sim", data: questao_13[0] },
            { label: "Não", data: questao_13[1] },
            { label: "Sem resposta", data: questao_13[2] },
        ];
    } else if (questao == "#questao14") {
        return [
            { label: "Sim", data: questao_14[0] },
            { label: "Não", data: questao_14[1] },
            { label: "Sem resposta", data: questao_14[2] },
        ];
    } else if (questao == "#questao15") {
        return [
            { label: "Sim", data: questao_15[0] },
            { label: "Não está em condições de uso", data: questao_15[1] },
            { label: "Não tem quadra de esportes", data: questao_15[2] },
            { label: "Sem resposta", data: questao_15[3] },
        ];
    } else if (questao == "#questao16") {
        return [
            { label: "1", data: questao_16[0] },
            { label: "2", data: questao_16[1] },
            { label: "3 ou mais", data: questao_16[2] },
            { label: "Sem resposta", data: questao_16[3] },
        ];
    } else if (questao == "#questao17") {
        return [
            { label: "Nenhuma", data: questao_17[0] },
            { label: "1", data: questao_17[1] },
            { label: "2", data: questao_17[2] },
            { label: "3 ou mais", data: questao_17[3] },
            { label: "Todas", data: questao_17[4] },
            { label: "Sem resposta", data: questao_17[5] },
        ];
    } else if (questao == "#questao18") {
        return [
            { label: "Sim", data: questao_18[0] },
            { label: "Não está em condições de uso", data: questao_18[1] },
            { label: "Não tem pista de atletismo", data: questao_18[2] },
            { label: "Sem resposta", data: questao_18[3] },
        ];
    } else if (questao == "#questao19") {
        return [
            { label: "Sim", data: questao_19[0] },
            { label: "Não está em condições de uso", data: questao_19[1] },
            { label: "Não tem piscina", data: questao_19[2] },
            { label: "Sem resposta", data: questao_19[3] },
        ];
    } else if (questao == "#questao20") {
        return [
            { label: "Sim", data: questao_20[0] },
            { label: "Não é utilizado para prática regular de atividade física com instrutor", data: questao_20[1] },
            { label: "Não tem pátio", data: questao_20[2] },
            { label: "Sem resposta", data: questao_20[3] },
        ];
    } else if (questao == "#questao21") {
        return [
            { label: "Sim", data: questao_21[0] },
            { label: "Não está em condições de uso", data: questao_21[1] },
            { label: "Não tem material esportivo para jogos e brincadeiras", data: questao_21[2] },
            { label: "Sem resposta", data: questao_21[3] },
        ];
    } else if (questao == "#questao22") {
        return [
            { label: "Sim", data: questao_22[0] },
            { label: "Não está em condições de uso", data: questao_22[1] },
            { label: "Não tem vestiário", data: questao_22[2] },
            { label: "Sem resposta", data: questao_22[3] },
        ];
    } else if (questao == "#questao23") {
        return [
            { label: "Sim", data: questao_23[0] },
            { label: "Não estão em condições de uso", data: questao_23[1] },
            { label: "Não tem vestiários separados", data: questao_23[2] },
            { label: "Sem resposta", data: questao_23[3] },
        ];
    } else if (questao == "#questao24") {
        return [
            { label: "Sim, gratuito", data: questao_24[0] },
            { label: "Sim, pago", data: questao_24[1] },
            { label: "Sim, pago e gratuito", data: questao_24[2] },
            { label: "Não", data: questao_24[3] },
            { label: "Sem resposta", data: questao_24[4] },
        ];
    } else if (questao == "#questao25") {
        return [
            { label: "Sim", data: questao_25[0] },
            { label: "Não", data: questao_25[1] },
            { label: "Sem resposta", data: questao_25[2] },
        ];
    } else if (questao == "#questao26") {
        return [
            { label: "Sim", data: questao_26[0] },
            { label: "Não", data: questao_26[1] },
            { label: "Sem resposta", data: questao_26[2] },
        ];
    } else if (questao == "#questao27") {
        return [
            { label: "Sim", data: questao_27[0] },
            { label: "Não", data: questao_27[1] },
            { label: "Sem resposta", data: questao_27[2] },
        ];
    } else if (questao == "#questao28") {
        return [
            { label: "Deficiência intelectual", data: questao_28[0] },
            { label: "Transtornos do espectro do autismo", data: questao_28[1] },
            { label: "Transtornos mentais e de comportamento", data: questao_28[2] },
            { label: "Deficiência física", data: questao_28[3] },
            { label: "Deficiência auditiva", data: questao_28[4] },
            { label: "Deficiência visual", data: questao_28[5] },
            { label: "Deficiência múltipla (2 ou mais deficiências simultâneas)", data: questao_28[6] },
            { label: "Outros", data: questao_28[7] },
            { label: "Sem resposta", data: questao_28[8] },
        ];
    } else if (questao == "#questao29") {
        return [
            { label: "Sim", data: questao_29[0] },
            { label: "Não", data: questao_29[1] },
            { label: "Sem resposta", data: questao_29[2] },
        ];
    } else if (questao == "#questao30") {
        return [
            { label: "Sim", data: questao_30[0] },
            { label: "Não", data: questao_30[1] },
            { label: "Sem resposta", data: questao_30[2] },
        ];
    } else if (questao == "#questao31") {
        return [
            { label: "Rampas de acesso", data: questao_31[0] },
            { label: "Interior adequado para locomoção", data: questao_31[1] },
            { label: "Móveis adequados para alunos com necessidades especiais", data: questao_31[2] },
            { label: "Sanitário adequado para alunos com necessidades especiais", data: questao_31[3] },
            { label: "Sem resposta", data: questao_31[4] },
        ];
    } else if (questao == "#questao32") {
        return [
            { label: "Sim", data: questao_32[0] },
            { label: "Não", data: questao_32[1] },
            { label: "Sem resposta", data: questao_32[2] },
        ];
    } else if (questao == "#questao33") {
        return [
            { label: "Manhã", data: questao_33[0] },
            { label: "Intermediário", data: questao_33[1] },
            { label: "Tarde", data: questao_33[2] },
            { label: "Noite", data: questao_33[3] },
            { label: "Integral", data: questao_33[4] },
            { label: "Internato", data: questao_33[5] },
            { label: "Educação Infantil", data: questao_33[6] },
            { label: "1o a 5o ano do Ensino Fundamental", data: questao_33[7] },
            { label: "6o a 9o ano do Ensino Fundamental", data: questao_33[8] },
            { label: "Ensino Médio", data: questao_33[9] },
            { label: "Educação de Jovens e Adultos", data: questao_33[10] },
            { label: "Sem resposta", data: questao_33[11] },
        ];
    } else if (questao == "#questao34") {
        return [
            { label: "Sim", data: questao_34[0] },
            { label: "Não está em condições de uso", data: questao_34[1] },
            { label: "Não tem cozinha", data: questao_34[2] },
            { label: "Sem resposta", data: questao_34[3] },
        ];
    } else if (questao == "#questao35") {
        return [
            { label: "Sim", data: questao_35[0] },
            { label: "Não está em condições de uso", data: questao_35[1] },
            { label: "Não tem refeitório", data: questao_35[2] },
            { label: "Sem resposta", data: questao_35[3] },
        ];
    } else if (questao == "#questao36") {
        return [
            { label: "Sim", data: questao_36[0] },
            { label: "Não", data: questao_36[1] },
            { label: "Sem resposta", data: questao_36[2] },
        ];
    } else if (questao == "#questao37") {
        return [
            { label: "Refrigerante", data: questao_37[0] },
            { label: "Suco ou refresco natural de frutas", data: questao_37[1] },
            { label: "Bebidas açucaradas (suco artificial, chá gelado, isotônicos, águas com sabor, energéticos, leite de soja etc. Não contar bebida láctea)", data: questao_37[2] },
            { label: "Leite ou bebida a base de leite (excluir leite de soja)", data: questao_37[3] },
            { label: "Salgados fritos (coxinha, pastel, quibe, batata frita etc)", data: questao_37[4] },
            { label: "Salgados assados (pastel, empada, esfirra etc)", data: questao_37[5] },
            { label: "Salgadinhos industrializados vendidos em pacotes, tipo “chips” e outros (incluindo batata frita de pacote)", data: questao_37[6] },
            { label: "Biscoitos ou bolachas salgadas ou doces, balas, confeitos, doces, chocolates, sorvetes, dim-dim, sacolé, chupe-chupe e outros", data: questao_37[7] },
            { label: "Sanduíches (cachorro quente, misto quente, hambúrguer etc)", data: questao_37[8] },
            { label: "Frutas frescas ou salada de frutas", data: questao_37[9] },
            { label: "Sem resposta", data: questao_37[10] },
        ];
    } else if (questao == "#questao38") {
        return [
            { label: "Sim", data: questao_38[0] },
            { label: "Não", data: questao_38[1] },
            { label: "Sem resposta", data: questao_38[2] },
        ];
    } else if (questao == "#questao39") {
        return [
            { label: "Refrigerante", data: questao_39[0] },
            { label: "Suco ou refresco natural de frutas", data: questao_39[1] },
            { label: "Bebidas açucaradas (suco artificial, chá gelado, isotônicos, águas com sabor, energéticos, leite de soja etc. Não contar bebida láctea)", data: questao_39[2] },
            { label: "Leite ou bebida a base de leite (excluir leite de soja)", data: questao_39[3] },
            { label: "Salgados fritos (coxinha, pastel, quibe, batata frita etc)", data: questao_39[4] },
            { label: "Salgados assados (pastel, empada, esfirra etc)", data: questao_39[5] },
            { label: "Salgadinhos industrializados vendidos em pacotes, tipo “chips” e outros (incluindo batata frita de pacote)", data: questao_39[6] },
            { label: "Biscoitos ou bolachas salgadas ou doces", data: questao_39[7] },
            { label: "Balas, confeitos, doces, chocolates, sorvetes, dim-dim, sacolé, chupe-chupe e outros", data: questao_39[8] },
            { label: "Sanduíches (cachorro quente, misto quente, hambúrguer etc)", data: questao_39[9] },
            { label: "Frutas frescas ou salada de frutas", data: questao_39[10] },
            { label: "Sem resposta", data: questao_39[11] },
        ];
    } else if (questao == "#questao40") {
        return [
            { label: "Sim", data: questao_40[0] },
            { label: "Não", data: questao_40[1] },
            { label: "Sem resposta", data: questao_40[2] },
        ];
    } else if (questao == "#questao41") {
        return [
            { label: "Sim", data: questao_41[0] },
            { label: "Não", data: questao_41[1] },
            { label: "Não tem água", data: questao_41[2] },
            { label: "Sem resposta", data: questao_41[3] },
        ];
    } else if (questao == "#questao42") {
        return [
            { label: "Sim", data: questao_42[0] },
            { label: "Não", data: questao_42[1] },
            { label: "Não sabe", data: questao_42[2] },
            { label: "Sem resposta", data: questao_42[3] },
        ];
    } else if (questao == "#questao43") {
        return [
            { label: "Rede de abastecimento de água", data: questao_43[0] },
            { label: "Poço ou nascente", data: questao_43[1] },
            { label: "Água de chuva (cisterna)", data: questao_43[2] },
            { label: "Açude, lago ou rio", data: questao_43[3] },
            { label: "Outra fonte", data: questao_43[4] },
            { label: "Sem resposta", data: questao_43[5] },
        ];
    } else if (questao == "#questao44") {
        return [
            { label: "Sim", data: questao_44[0] },
            { label: "Não está em condições de uso", data: questao_44[1] },
            { label: "Não tem banheiro", data: questao_44[2] },
            { label: "Sem resposta", data: questao_44[3] },
        ];
    } else if (questao == "#questao45") {
        return [
            { label: "Sim", data: questao_45[0] },
            { label: "Não estão em condições de uso", data: questao_45[1] },
            { label: "Não tem banheiros separados", data: questao_45[2] },
            { label: "Sem resposta", data: questao_45[3] },
        ];
    } else if (questao == "#questao46") {
        return [
            { label: "Sim", data: questao_46[0] },
            { label: "Não", data: questao_46[1] },
            { label: "Sem resposta", data: questao_46[2] },
        ];
    } else if (questao == "#questao47") {
        return [
            { label: "Sim", data: questao_47[0] },
            { label: "Não está em condições de uso", data: questao_47[1] },
            { label: "Não tem pia ou lavatório", data: questao_47[2] },
            { label: "Sem resposta", data: questao_47[3] },
        ];
    } else if (questao == "#questao48") {
        return [
            { label: "Sim", data: questao_48[0] },
            { label: "Não", data: questao_48[1] },
            { label: "Sem resposta", data: questao_48[2] },
        ];
    } else if (questao == "#questao49") {
        return [
            { label: "Nenhum dia por semana", data: questao_49[0] },
            { label: "1 a 2 dias por semana", data: questao_49[1] },
            { label: "3 a 4 dias por semana", data: questao_49[2] },
            { label: "5 a 6 dias por semana", data: questao_49[3] },
            { label: "Todos os dias da semana", data: questao_49[4] },
            { label: "Sem resposta", data: questao_49[5] },
        ];
    } else if (questao == "#questao50") {
        return [
            { label: "Sim", data: questao_50[0] },
            { label: "Não", data: questao_50[1] },
            { label: "Sem resposta", data: questao_50[2] },
        ];
    } else if (questao == "#questao51") {
        return [
            { label: "Sim", data: questao_51[0] },
            { label: "Não (pular para a questão X)", data: questao_51[1] },
            { label: "Sem resposta", data: questao_51[2] },
        ];
    } else if (questao == "#questao52") {
        return [
            { label: "Sim", data: questao_52[0] },
            { label: "Não", data: questao_52[1] },
            { label: "Sem resposta", data: questao_52[2] },
        ];
    } else if (questao == "#questao53") {
        return [
            { label: "Todos os dias letivos", data: questao_53[0] },
            { label: "Uma vez por semana", data: questao_53[1] },
            { label: "Duas vezes por semana", data: questao_53[2] },
            { label: "Três ou mais vezes por semana", data: questao_53[3] },
            { label: "Uma vez por mês", data: questao_53[4] },
            { label: "Duas vezes por mês", data: questao_53[5] },
            { label: "Uma vez a cada dois meses", data: questao_53[6] },
            { label: "Uma vez a cada três meses", data: questao_53[7] },
            { label: "Uma vez por semestre", data: questao_53[8] },
            { label: "Uma vez por ano", data: questao_53[9] },
            { label: "Sem resposta", data: questao_53[10] },
        ];
    } else if (questao == "#questao54") {
        return [
            { label: "Sim", data: questao_54[0] },
            { label: "Não", data: questao_54[1] },
            { label: "Sem resposta", data: questao_54[2] },
        ];
    } else if (questao == "#questao55") {
        return [
            { label: "Todos os dias letivos", data: questao_55[0] },
            { label: "Uma vez por semana", data: questao_55[1] },
            { label: "Duas vezes por semana", data: questao_55[2] },
            { label: "Três ou mais vezes por semana", data: questao_55[3] },
            { label: "Uma vez por mês", data: questao_55[4] },
            { label: "Duas vezes por mês", data: questao_55[5] },
            { label: "Uma vez a cada dois meses", data: questao_55[6] },
            { label: "Uma vez a cada três meses", data: questao_55[7] },
            { label: "Uma vez por semestre", data: questao_55[8] },
            { label: "Uma vez por ano", data: questao_55[9] },
            { label: "Sem resposta", data: questao_55[10] },
        ];
    } else if (questao == "#questao56") {
        return [
            { label: "Sim", data: questao_56[0] },
            { label: "Não", data: questao_56[1] },
            { label: "Sem resposta", data: questao_56[2] },
        ];
    } else if (questao == "#questao57") {
        return [
            { label: "Todos os dias letivos", data: questao_57[0] },
            { label: "Uma vez por semana", data: questao_57[1] },
            { label: "Duas vezes por semana", data: questao_57[2] },
            { label: "Três ou mais vezes por semana", data: questao_57[3] },
            { label: "Uma vez por mês", data: questao_57[4] },
            { label: "Duas vezes por mês", data: questao_57[5] },
            { label: "Uma vez a cada dois meses", data: questao_57[6] },
            { label: "Uma vez a cada três meses", data: questao_57[7] },
            { label: "Uma vez por semestre", data: questao_57[8] },
            { label: "Uma vez por ano", data: questao_57[9] },
            { label: "Sem resposta", data: questao_57[10] },
        ];
    } else if (questao == "#questao58") {
        return [
            { label: "Sim", data: questao_58[0] },
            { label: "Não", data: questao_58[1] },
            { label: "Sem resposta", data: questao_58[2] },
        ];
    } else if (questao == "#questao59") {
        return [
            { label: "Sim", data: questao_59[0] },
            { label: "Não", data: questao_59[1] },
            { label: "Sem resposta", data: questao_59[2] },
        ];
    } else if (questao == "#questao60") {
        return [
            { label: "Sim", data: questao_60[0] },
            { label: "Não", data: questao_60[1] },
            { label: "Sem resposta", data: questao_60[2] },
        ];
    } else if (questao == "#questao61") {
        return [
            { label: "Sim", data: questao_61[0] },
            { label: "Não", data: questao_61[1] },
            { label: "Sem resposta", data: questao_61[2] },
        ];
    } else if (questao == "#questao62") {
        return [
            { label: "Sim", data: questao_62[0] },
            { label: "Não", data: questao_62[1] },
            { label: "Sem resposta", data: questao_62[2] },
        ];
    } else if (questao == "#questao63") {
        return [
            { label: "Mensalmente", data: questao_63[0] },
            { label: "Bimestralmente", data: questao_63[1] },
            { label: "Trimestralmente", data: questao_63[2] },
            { label: "Uma vez por ano", data: questao_63[3] },
            { label: "Sem resposta", data: questao_63[4] },
        ];
    } else if (questao == "#questao64") {
        return [
            { label: "Sim", data: questao_64[0] },
            { label: "Não", data: questao_64[1] },
            { label: "Sem resposta", data: questao_64[2] },
        ];
    } else if (questao == "#questao65") {
        return [
            { label: "Sim", data: questao_65[0] },
            { label: "Não", data: questao_65[1] },
            { label: "Sem resposta", data: questao_65[2] },
        ];
    } else if (questao == "#questao66") {
        return [
            { label: "Nenhuma vez", data: questao_66[0] },
            { label: "Raramente", data: questao_66[1] },
            { label: "Às vezes", data: questao_66[2] },
            { label: "Na maior parte do tempo", data: questao_66[3] },
            { label: "Em todo período", data: questao_66[4] },
            { label: "Sem resposta", data: questao_66[5] },
        ];
    } else if (questao == "#questao67") {
        return [
            { label: "Nenhuma vez", data: questao_67[0] },
            { label: "1 vez", data: questao_67[1] },
            { label: "2 a 4 vezes", data: questao_67[2] },
            { label: "5 ou mais vezes", data: questao_67[3] },
            { label: "Sem resposta", data: questao_67[4] },
        ];
    } else if (questao == "#questao68") {
        return [
            { label: "Sim", data: questao_68[0] },
            { label: "Não", data: questao_68[1] },
            { label: "Sem resposta", data: questao_68[2] },
        ];
    } else if (questao == "#questao69") {
        return [
            { label: "Sim", data: questao_69[0] },
            { label: "Não", data: questao_69[1] },
            { label: "Sem resposta", data: questao_69[2] },
        ];
    } else if (questao == "#questao70") {
        return [
            { label: "2013", data: questao_70[0] },
            { label: "2014", data: questao_70[1] },
            { label: "2015", data: questao_70[2] },
            { label: "2016", data: questao_70[3] },
            { label: "2017", data: questao_70[4] },
            { label: "2018", data: questao_70[5] },
            { label: "Não sei.", data: questao_70[6] },
            { label: "Sem resposta", data: questao_70[7] },
        ];
    } else if (questao == "#questao71") {
        return [
            { label: "Sim", data: questao_71[0] },
            { label: "Não", data: questao_71[1] },
            { label: "Sem resposta", data: questao_71[2] },
        ];
    } else if (questao == "#questao72") {
        return [
            { label: "Sim", data: questao_72[0] },
            { label: "Não", data: questao_72[1] },
            { label: "Sem resposta", data: questao_72[2] },
        ];
    } else if (questao == "#questao73") {
        return [
            { label: "Sim", data: questao_73[0] },
            { label: "Não", data: questao_73[1] },
            { label: "Sem resposta", data: questao_73[2] },
        ];
    } else if (questao == "#questao74") {
        return [
            { label: "Sim", data: questao_74[0] },
            { label: "Não", data: questao_74[1] },
            { label: "Sem resposta", data: questao_74[2] },
        ];
    } else if (questao == "#questao75") {
        return [
            { label: "Sim", data: questao_75[0] },
            { label: "Não", data: questao_75[1] },
            { label: "Sem resposta", data: questao_75[2] },
        ];
    } else if (questao == "#questao76") {
        return [
            { label: "Sim", data: questao_76[0] },
            { label: "Não", data: questao_76[1] },
            { label: "Sem resposta", data: questao_76[2] },
        ];
    } else if (questao == "#questao77") {
        return [
            { label: "Sim", data: questao_77[0] },
            { label: "Não", data: questao_77[1] },
            { label: "Sem resposta", data: questao_77[2] },
        ];
    } else if (questao == "#questao78") {
        return [
            { label: "Sim", data: questao_78[0] },
            { label: "Não", data: questao_78[1] },
            { label: "Sem resposta", data: questao_78[2] },
        ];
    } else if (questao == "#questao79") {
        return [
            { label: "Sim", data: questao_79[0] },
            { label: "Não", data: questao_79[1] },
            { label: "Sem resposta", data: questao_79[2] },
        ];
    } else if (questao == "#questao80") {
        return [
            { label: "Sim", data: questao_80[0] },
            { label: "Não", data: questao_80[1] },
            { label: "Sem resposta", data: questao_80[2] },
        ];
    } else if (questao == "#questao81") {
        return [
            { label: "Sim", data: questao_81[0] },
            { label: "Não", data: questao_81[1] },
            { label: "Sem resposta", data: questao_81[2] },
        ];
    } else if (questao == "#questao82") {
        return [
            { label: "Sim", data: questao_82[0] },
            { label: "Não", data: questao_82[1] },
            { label: "Sem resposta", data: questao_82[2] },
        ];
    } else if (questao == "#questao83") {
        return [
            { label: "Sim", data: questao_83[0] },
            { label: "Não", data: questao_83[1] },
            { label: "Sem resposta", data: questao_83[2] },
        ];
    } else if (questao == "#questao84") {
        return [
            { label: "Sim", data: questao_84[0] },
            { label: "Não", data: questao_84[1] },
            { label: "Sem resposta", data: questao_84[2] },
        ];
    }
}

document.getElementById("baixa-grafico-1").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao1')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-2").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao2')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-3").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao3')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-4").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao4')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-5").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao5')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-6").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao6')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-7").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao7')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-8").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao8')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-9").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao9')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-10").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao10')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-11").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao11')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-12").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao12')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-13").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao13')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-14").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao14')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-15").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao15')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-16").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao16')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-17").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao17')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-18").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao18')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-19").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao19')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-20").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao20')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-21").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao21')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-22").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao22')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-23").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao23')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-24").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao24')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-25").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao25')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-26").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao26')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-27").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao27')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-28").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao28')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-29").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao29')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-30").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao30')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-31").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao31')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-32").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao32')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-33").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao33')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-34").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao34')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-35").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao35')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-36").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao36')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-37").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao37')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-38").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao38')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-39").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao39')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-40").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao40')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-41").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao41')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-42").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao42')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-43").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao43')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-44").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao44')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-45").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao45')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-46").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao46')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-47").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao47')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-48").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao48')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-49").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao49')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-50").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao50')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-51").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao51')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-52").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao52')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-53").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao53')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-54").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao54')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-55").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao55')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-56").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao56')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-57").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao57')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-58").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao58')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-59").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao59')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-60").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao60')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-61").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao61')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-62").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao62')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-63").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao63')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-64").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao64')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-65").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao65')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-66").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao66')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-67").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao67')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-68").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao68')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-69").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao69')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-70").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao70')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-71").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao71')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-72").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao72')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-73").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao73')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-74").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao74')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-75").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao75')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-76").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao76')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-77").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao77')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-78").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao78')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-79").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao79')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-80").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao80')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-81").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao81')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-82").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao82')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-83").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao83')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-84").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao84')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

function baixaImagem(uri, filename) {
    var link = document.createElement('a');
    
    if (typeof link.download === 'string') {
        link.href = uri;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    } else {
        window.open(uri);
    }
}
