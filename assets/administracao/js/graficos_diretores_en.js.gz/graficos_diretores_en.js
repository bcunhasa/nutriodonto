// Funções para criação de gráficos

document.addEventListener("DOMContentLoaded", function() {
    criaGraficoQuestao("#questao1", carregaDados("#questao1"));
    criaGraficoQuestao("#questao2", carregaDados("#questao2"));
    criaGraficoQuestao("#questao3", carregaDados("#questao3"));
    criaGraficoQuestao("#questao4", carregaDados("#questao4"));
    criaGraficoQuestao("#questao5", carregaDados("#questao5"));
    criaGraficoQuestao("#questao6", carregaDados("#questao6"));
    criaGraficoQuestao("#questao7", carregaDados("#questao7"));
    criaGraficoQuestao("#questao8", carregaDados("#questao8"));
    criaGraficoQuestao("#questao9", carregaDados("#questao9"));
    criaGraficoQuestao("#questao10", carregaDados("#questao10"));
    criaGraficoQuestao("#questao11", carregaDados("#questao11"));
    criaGraficoQuestao("#questao12", carregaDados("#questao12"));
    criaGraficoQuestao("#questao13", carregaDados("#questao13"));
    criaGraficoQuestao("#questao14", carregaDados("#questao14"));
    criaGraficoQuestao("#questao15", carregaDados("#questao15"));
    criaGraficoQuestao("#questao16", carregaDados("#questao16"));
    criaGraficoQuestao("#questao17", carregaDados("#questao17"));
    criaGraficoQuestao("#questao18", carregaDados("#questao18"));
    criaGraficoQuestao("#questao19", carregaDados("#questao19"));
    criaGraficoQuestao("#questao20", carregaDados("#questao20"));
    criaGraficoQuestao("#questao21", carregaDados("#questao21"));
    criaGraficoQuestao("#questao22", carregaDados("#questao22"));
    criaGraficoQuestao("#questao23", carregaDados("#questao23"));
    criaGraficoQuestao("#questao24", carregaDados("#questao24"));
    criaGraficoQuestao("#questao25", carregaDados("#questao25"));
    criaGraficoQuestao("#questao26", carregaDados("#questao26"));
    criaGraficoQuestao("#questao27", carregaDados("#questao27"));
    criaGraficoQuestao("#questao28", carregaDados("#questao28"));
    criaGraficoQuestao("#questao29", carregaDados("#questao29"));
    criaGraficoQuestao("#questao30", carregaDados("#questao30"));
    criaGraficoQuestao("#questao31", carregaDados("#questao31"));
    criaGraficoQuestao("#questao32", carregaDados("#questao32"));
    criaGraficoQuestao("#questao33", carregaDados("#questao33"));
    criaGraficoQuestao("#questao34", carregaDados("#questao34"));
    criaGraficoQuestao("#questao35", carregaDados("#questao35"));
    criaGraficoQuestao("#questao36", carregaDados("#questao36"));
    criaGraficoQuestao("#questao37", carregaDados("#questao37"));
    criaGraficoQuestao("#questao38", carregaDados("#questao38"));
    criaGraficoQuestao("#questao39", carregaDados("#questao39"));
    criaGraficoQuestao("#questao40", carregaDados("#questao40"));
    criaGraficoQuestao("#questao41", carregaDados("#questao41"));
    criaGraficoQuestao("#questao42", carregaDados("#questao42"));
    criaGraficoQuestao("#questao43", carregaDados("#questao43"));
    criaGraficoQuestao("#questao44", carregaDados("#questao44"));
    criaGraficoQuestao("#questao45", carregaDados("#questao45"));
    criaGraficoQuestao("#questao46", carregaDados("#questao46"));
    criaGraficoQuestao("#questao47", carregaDados("#questao47"));
    criaGraficoQuestao("#questao48", carregaDados("#questao48"));
    criaGraficoQuestao("#questao49", carregaDados("#questao49"));
    criaGraficoQuestao("#questao50", carregaDados("#questao50"));
    criaGraficoQuestao("#questao51", carregaDados("#questao51"));
    criaGraficoQuestao("#questao52", carregaDados("#questao52"));
    criaGraficoQuestao("#questao53", carregaDados("#questao53"));
    criaGraficoQuestao("#questao54", carregaDados("#questao54"));
    criaGraficoQuestao("#questao55", carregaDados("#questao55"));
    criaGraficoQuestao("#questao56", carregaDados("#questao56"));
    criaGraficoQuestao("#questao57", carregaDados("#questao57"));
    criaGraficoQuestao("#questao58", carregaDados("#questao58"));
    criaGraficoQuestao("#questao59", carregaDados("#questao59"));
    criaGraficoQuestao("#questao60", carregaDados("#questao60"));
    criaGraficoQuestao("#questao61", carregaDados("#questao61"));
    criaGraficoQuestao("#questao62", carregaDados("#questao62"));
    criaGraficoQuestao("#questao63", carregaDados("#questao63"));
    criaGraficoQuestao("#questao64", carregaDados("#questao64"));
    criaGraficoQuestao("#questao65", carregaDados("#questao65"));
    criaGraficoQuestao("#questao66", carregaDados("#questao66"));
    criaGraficoQuestao("#questao67", carregaDados("#questao67"));
    criaGraficoQuestao("#questao68", carregaDados("#questao68"));
    criaGraficoQuestao("#questao69", carregaDados("#questao69"));
    criaGraficoQuestao("#questao70", carregaDados("#questao70"));
    criaGraficoQuestao("#questao71", carregaDados("#questao71"));
    criaGraficoQuestao("#questao72", carregaDados("#questao72"));
    criaGraficoQuestao("#questao73", carregaDados("#questao73"));
    criaGraficoQuestao("#questao74", carregaDados("#questao74"));
    criaGraficoQuestao("#questao75", carregaDados("#questao75"));
    criaGraficoQuestao("#questao76", carregaDados("#questao76"));
    criaGraficoQuestao("#questao77", carregaDados("#questao77"));
    criaGraficoQuestao("#questao78", carregaDados("#questao78"));
    criaGraficoQuestao("#questao79", carregaDados("#questao79"));
    criaGraficoQuestao("#questao80", carregaDados("#questao80"));
    criaGraficoQuestao("#questao81", carregaDados("#questao81"));
    criaGraficoQuestao("#questao82", carregaDados("#questao82"));
    criaGraficoQuestao("#questao83", carregaDados("#questao83"));
    criaGraficoQuestao("#questao84", carregaDados("#questao84"));
});

function criaGraficoQuestao(questao, dados) {
    var data = dados;
    
    $.plot($(questao), data, { 
        series: {
            pie: {
                show: true,
                radius: 1,
                label: {
                    show: true,
                    radius: 0.9,
                    formatter: function (label, series) {
                        return '<div class="flot-pie-label">' + Math.round(series.percent) +'% (' + series.data[0][1] + ')</div>';
                    },
                    background: { 
                        opacity: 0.5,
                        color: '#000000'
                    }
                }
            }
        },
        grid: {
            hoverable: true
        },
        tooltip: true,
        tooltipOpts: {
            content: "%s: %p.0% (%y.0)",
        },
    });
}

function carregaDados(questao) {
    if (questao == "#questao1") {
        return [
            { label: "Morning", data: questao_1[0] },
            { label: "Intermediate", data: questao_1[1] },
            { label: "Evening", data: questao_1[2] },
            { label: "Night", data: questao_1[3] },
            { label: "No answer", data: questao_1[4] },
        ];
    } else if (questao == "#questao2") {
        return [
            { label: "Yes", data: questao_2[0] },
            { label: "No", data: questao_2[1] },
            { label: "No answer", data: questao_2[2] },
        ];
    } else if (questao == "#questao3") {
        return [
            { label: "Early Childhood Education (kindergarten, preschool)", data: questao_3[0] },
            { label: "Elementary School (8 years, 9 years)", data: questao_3[1] },
            { label: "High School (High School, Integrated, Normal / Teaching, Vocational Education)", data: questao_3[2] },
            { label: "Youth and Adult Education (elementary, urban, middle school)", data: questao_3[3] },
            { label: "No answer", data: questao_3[4] },
        ];
    } else if (questao == "#questao4") {
        return [
            { label: "Up to 50 students", data: questao_4[0] },
            { label: "From 51 to 100 students", data: questao_4[1] },
            { label: "From 101 to 200 students", data: questao_4[2] },
            { label: "From 201 to 500 students", data: questao_4[3] },
            { label: "From 501 to 1,000 students", data: questao_4[4] },
            { label: "1,000+ students", data: questao_4[5] },
            { label: "No answer", data: questao_4[6] },
        ];
    } else if (questao == "#questao5") {
        return [
            { label: "Up to 10 rooms", data: questao_5[0] },
            { label: "11 to 20 rooms", data: questao_5[1] },
            { label: "21 to 30 rooms", data: questao_5[2] },
            { label: "31 to 40 rooms", data: questao_5[3] },
            { label: "41 to 50 rooms", data: questao_5[4] },
            { label: "More than 50 rooms", data: questao_5[5] },
            { label: "No answer", data: questao_5[6] },
        ];
    } else if (questao == "#questao6") {
        return [
            { label: "Yes", data: questao_6[0] },
            { label: "Not in use condition", data: questao_6[1] },
            { label: "Has no library", data: questao_6[2] },
            { label: "No answer", data: questao_6[3] },
        ];
    } else if (questao == "#questao7") {
        return [
            { label: "Yes", data: questao_7[0] },
            { label: "Not in use condition", data: questao_7[1] },
            { label: "No computer room or lab", data: questao_7[2] },
            { label: "No answer", data: questao_7[3] },
        ];
    } else if (questao == "#questao8") {
        return [
            { label: "There are no working computers for students", data: questao_8[0] },
            { label: "Up to 10 computers", data: questao_8[1] },
            { label: "11 to 20 computers", data: questao_8[2] },
            { label: "21 to 30 computers", data: questao_8[3] },
            { label: "31 to 40 computers", data: questao_8[4] },
            { label: "41 to 50 computers", data: questao_8[5] },
            { label: "50+ computers", data: questao_8[6] },
            { label: "No answer", data: questao_8[7] },
        ];
    } else if (questao == "#questao9") {
        return [
            { label: "Yes", data: questao_9[0] },
            { label: "No", data: questao_9[1] },
            { label: "No answer", data: questao_9[2] },
        ];
    } else if (questao == "#questao10") {
        return [
            { label: "Yes", data: questao_10[0] },
            { label: "Not in use condition", data: questao_10[1] },
            { label: "No media/communication resource room", data: questao_10[2] },
            { label: "No answer", data: questao_10[3] },
        ];
    } else if (questao == "#questao11") {
        return [
            { label: "Yes", data: questao_11[0] },
            { label: "No", data: questao_11[1] },
            { label: "No answer", data: questao_11[2] },
        ];
    } else if (questao == "#questao12") {
        return [
            { label: "Does not meet often", data: questao_12[0] },
            { label: "1 to 3 times a year", data: questao_12[1] },
            { label: "4 to 6 times a year", data: questao_12[2] },
            { label: "7 to 9 times a year", data: questao_12[3] },
            { label: "10 to 12 times a year", data: questao_12[4] },
            { label: "More than 12 times a year", data: questao_12[5] },
            { label: "No answer", data: questao_12[6] },
        ];
    } else if (questao == "#questao13") {
        return [
            { label: "Yes", data: questao_13[0] },
            { label: "No", data: questao_13[1] },
            { label: "No answer", data: questao_13[2] },
        ];
    } else if (questao == "#questao14") {
        return [
            { label: "Yes", data: questao_14[0] },
            { label: "No", data: questao_14[1] },
            { label: "No answer", data: questao_14[2] },
        ];
    } else if (questao == "#questao15") {
        return [
            { label: "Yes", data: questao_15[0] },
            { label: "Not in use condition", data: questao_15[1] },
            { label: "There is no sports court", data: questao_15[2] },
            { label: "No answer", data: questao_15[3] },
        ];
    } else if (questao == "#questao16") {
        return [
            { label: "1", data: questao_16[0] },
            { label: "2", data: questao_16[1] },
            { label: "3 or more", data: questao_16[2] },
            { label: "No answer", data: questao_16[3] },
        ];
    } else if (questao == "#questao17") {
        return [
            { label: "None", data: questao_17[0] },
            { label: "1", data: questao_17[1] },
            { label: "2", data: questao_17[2] },
            { label: "3 or more", data: questao_17[3] },
            { label: "All", data: questao_17[4] },
            { label: "No answer", data: questao_17[5] },
        ];
    } else if (questao == "#questao18") {
        return [
            { label: "Yes", data: questao_18[0] },
            { label: "Not in use condition", data: questao_18[1] },
            { label: "There is no running track", data: questao_18[2] },
            { label: "No answer", data: questao_18[3] },
        ];
    } else if (questao == "#questao19") {
        return [
            { label: "Yes", data: questao_19[0] },
            { label: "Not in use condition", data: questao_19[1] },
            { label: "There is no pool", data: questao_19[2] },
            { label: "No answer", data: questao_19[3] },
        ];
    } else if (questao == "#questao20") {
        return [
            { label: "Yes", data: questao_20[0] },
            { label: "Not used for regular physical activity with instructor", data: questao_20[1] },
            { label: "No patio", data: questao_20[2] },
            { label: "No answer", data: questao_20[3] },
        ];
    } else if (questao == "#questao21") {
        return [
            { label: "Yes", data: questao_21[0] },
            { label: "Not in use condition", data: questao_21[1] },
            { label: "No sporting goods for games", data: questao_21[2] },
            { label: "No answer", data: questao_21[3] },
        ];
    } else if (questao == "#questao22") {
        return [
            { label: "Yes", data: questao_22[0] },
            { label: "Not in use condition", data: questao_22[1] },
            { label: "There is no locker room", data: questao_22[2] },
            { label: "No answer", data: questao_22[3] },
        ];
    } else if (questao == "#questao23") {
        return [
            { label: "Yes", data: questao_23[0] },
            { label: "Não estão em condições de uso", data: questao_23[1] },
            { label: "No separate locker rooms", data: questao_23[2] },
            { label: "No answer", data: questao_23[3] },
        ];
    } else if (questao == "#questao24") {
        return [
            { label: "Yes, free", data: questao_24[0] },
            { label: "Yes, caught", data: questao_24[1] },
            { label: "Yes, paid and free", data: questao_24[2] },
            { label: "No", data: questao_24[3] },
            { label: "No answer", data: questao_24[4] },
        ];
    } else if (questao == "#questao25") {
        return [
            { label: "Yes", data: questao_25[0] },
            { label: "No", data: questao_25[1] },
            { label: "No answer", data: questao_25[2] },
        ];
    } else if (questao == "#questao26") {
        return [
            { label: "Yes", data: questao_26[0] },
            { label: "No", data: questao_26[1] },
            { label: "No answer", data: questao_26[2] },
        ];
    } else if (questao == "#questao27") {
        return [
            { label: "Yes", data: questao_27[0] },
            { label: "No", data: questao_27[1] },
            { label: "No answer", data: questao_27[2] },
        ];
    } else if (questao == "#questao28") {
        return [
            { label: "Intellectual disability", data: questao_28[0] },
            { label: "Autism Spectrum Disorders", data: questao_28[1] },
            { label: "Mental and behavioral disorders", data: questao_28[2] },
            { label: "Physical disability", data: questao_28[3] },
            { label: "Hearing deficiency", data: questao_28[4] },
            { label: "Visual impairment", data: questao_28[5] },
            { label: "Multiple disability (2 or more concurrent disabilities)", data: questao_28[6] },
            { label: "Others", data: questao_28[7] },
            { label: "No answer", data: questao_28[8] },
        ];
    } else if (questao == "#questao29") {
        return [
            { label: "Yes", data: questao_29[0] },
            { label: "No", data: questao_29[1] },
            { label: "No answer", data: questao_29[2] },
        ];
    } else if (questao == "#questao30") {
        return [
            { label: "Yes", data: questao_30[0] },
            { label: "No", data: questao_30[1] },
            { label: "No answer", data: questao_30[2] },
        ];
    } else if (questao == "#questao31") {
        return [
            { label: "Access Ramps", data: questao_31[0] },
            { label: "Interior suitable for locomotion", data: questao_31[1] },
            { label: "Furniture suitable for students with special needs", data: questao_31[2] },
            { label: "Sanitary suitable for students with special needs", data: questao_31[3] },
            { label: "No answer", data: questao_31[4] },
        ];
    } else if (questao == "#questao32") {
        return [
            { label: "Yes", data: questao_32[0] },
            { label: "No", data: questao_32[1] },
            { label: "No answer", data: questao_32[2] },
        ];
    } else if (questao == "#questao33") {
        return [
            { label: "Morning", data: questao_33[0] },
            { label: "Intermediate", data: questao_33[1] },
            { label: "Evening", data: questao_33[2] },
            { label: "Night", data: questao_33[3] },
            { label: "Integral", data: questao_33[4] },
            { label: "Boarding school", data: questao_33[5] },
            { label: "Child education", data: questao_33[6] },
            { label: "1st to 5th grade of elementary school", data: questao_33[7] },
            { label: "6th to 9th grade of elementary school", data: questao_33[8] },
            { label: "High school", data: questao_33[9] },
            { label: "Youth and Adult Education", data: questao_33[10] },
            { label: "No answer", data: questao_33[11] },
        ];
    } else if (questao == "#questao34") {
        return [
            { label: "Yes", data: questao_34[0] },
            { label: "Not in use condition", data: questao_34[1] },
            { label: "No kitchen", data: questao_34[2] },
            { label: "No answer", data: questao_34[3] },
        ];
    } else if (questao == "#questao35") {
        return [
            { label: "Yes", data: questao_35[0] },
            { label: "Not in use condition", data: questao_35[1] },
            { label: "No refectory", data: questao_35[2] },
            { label: "No answer", data: questao_35[3] },
        ];
    } else if (questao == "#questao36") {
        return [
            { label: "Yes", data: questao_36[0] },
            { label: "No", data: questao_36[1] },
            { label: "No answer", data: questao_36[2] },
        ];
    } else if (questao == "#questao37") {
        return [
            { label: "Soda", data: questao_37[0] },
            { label: "Natural fruit juice or refreshment", data: questao_37[1] },
            { label: "Sugary drinks (artificial juice, iced tea, isotonic drinks, flavored waters, energy drinks, soy milk etc. Not counting dairy drink)", data: questao_37[2] },
            { label: "Milk or milk-based drink (excl. Soy milk)", data: questao_37[3] },
            { label: "Salty fritters (drumstick, pastry, kebab, chips etc)", data: questao_37[4] },
            { label: "Baked salty (pastries, patties, pies etc)", data: questao_37[5] },
            { label: "Processed chips sold in packs, chips and more (including packet chips)", data: questao_37[6] },
            { label: "Salty or sweet cookies or crackers, candies, confectionery, candies, chocolates, ice cream, dim-dim, sacolé, lollipop and others", data: questao_37[7] },
            { label: "Sandwiches (hot dog, hot joint, hamburger etc)", data: questao_37[8] },
            { label: "Fresh Fruit or Fruit Salad", data: questao_37[9] },
            { label: "No answer", data: questao_37[10] },
        ];
    } else if (questao == "#questao38") {
        return [
            { label: "Yes", data: questao_38[0] },
            { label: "No", data: questao_38[1] },
            { label: "No answer", data: questao_38[2] },
        ];
    } else if (questao == "#questao39") {
        return [
            { label: "Soda", data: questao_39[0] },
            { label: "Natural fruit juice or refreshment", data: questao_39[1] },
            { label: "Sugary drinks (artificial juice, iced tea, isotonic drinks, flavored waters, energy drinks, soy milk etc. Not counting dairy drink)", data: questao_39[2] },
            { label: "Milk or milk-based drink (excl. Soy milk)", data: questao_39[3] },
            { label: "Salty fritters (drumstick, pastry, kebab, chips etc)", data: questao_39[4] },
            { label: "Baked salty (pastries, patties, pies etc)", data: questao_39[5] },
            { label: "Processed chips sold in packs, chips and more (including packet chips)", data: questao_39[6] },
            { label: "Salty or sweet cookies or crackers, candies, confectionery, candies, chocolates, ice cream, dim-dim, sacolé, lollipop and others", data: questao_39[7] },
            { label: "Candies, confectionery, chocolates, ice cream and others", data: questao_39[8] },
            { label: "Sandwiches (hot dog, hot joint, hamburger etc)", data: questao_39[9] },
            { label: "Fresh Fruit or Fruit Salad", data: questao_39[10] },
            { label: "No answer", data: questao_39[11] },
        ];
    } else if (questao == "#questao40") {
        return [
            { label: "Yes", data: questao_40[0] },
            { label: "No", data: questao_40[1] },
            { label: "No answer", data: questao_40[2] },
        ];
    } else if (questao == "#questao41") {
        return [
            { label: "Yes", data: questao_41[0] },
            { label: "No", data: questao_41[1] },
            { label: "There is no water", data: questao_41[2] },
            { label: "No answer", data: questao_41[3] },
        ];
    } else if (questao == "#questao42") {
        return [
            { label: "Yes", data: questao_42[0] },
            { label: "No", data: questao_42[1] },
            { label: "Don’t know", data: questao_42[2] },
            { label: "No answer", data: questao_42[3] },
        ];
    } else if (questao == "#questao43") {
        return [
            { label: "Water supply network", data: questao_43[0] },
            { label: "Well or spring", data: questao_43[1] },
            { label: "Rainwater (cistern)", data: questao_43[2] },
            { label: "Weir, lake or river", data: questao_43[3] },
            { label: "Other source", data: questao_43[4] },
            { label: "No answer", data: questao_43[5] },
        ];
    } else if (questao == "#questao44") {
        return [
            { label: "Yes", data: questao_44[0] },
            { label: "Not in use condition", data: questao_44[1] },
            { label: "No bathroom", data: questao_44[2] },
            { label: "No answer", data: questao_44[3] },
        ];
    } else if (questao == "#questao45") {
        return [
            { label: "Yes", data: questao_45[0] },
            { label: "Não estão em condições de uso", data: questao_45[1] },
            { label: "No separate toilets", data: questao_45[2] },
            { label: "No answer", data: questao_45[3] },
        ];
    } else if (questao == "#questao46") {
        return [
            { label: "Yes", data: questao_46[0] },
            { label: "No", data: questao_46[1] },
            { label: "No answer", data: questao_46[2] },
        ];
    } else if (questao == "#questao47") {
        return [
            { label: "Yes", data: questao_47[0] },
            { label: "Not in use condition", data: questao_47[1] },
            { label: "No sink or washbasin", data: questao_47[2] },
            { label: "No answer", data: questao_47[3] },
        ];
    } else if (questao == "#questao48") {
        return [
            { label: "Yes", data: questao_48[0] },
            { label: "No", data: questao_48[1] },
            { label: "No answer", data: questao_48[2] },
        ];
    } else if (questao == "#questao49") {
        return [
            { label: "No days a week", data: questao_49[0] },
            { label: "1-2 days a week", data: questao_49[1] },
            { label: "3 to 4 days a week", data: questao_49[2] },
            { label: "5 to 6 days a week", data: questao_49[3] },
            { label: "Every day of the week", data: questao_49[4] },
            { label: "No answer", data: questao_49[5] },
        ];
    } else if (questao == "#questao50") {
        return [
            { label: "Yes", data: questao_50[0] },
            { label: "No", data: questao_50[1] },
            { label: "No answer", data: questao_50[2] },
        ];
    } else if (questao == "#questao51") {
        return [
            { label: "Yes", data: questao_51[0] },
            { label: "Não (skip to question X)", data: questao_51[1] },
            { label: "No answer", data: questao_51[2] },
        ];
    } else if (questao == "#questao52") {
        return [
            { label: "Yes", data: questao_52[0] },
            { label: "No", data: questao_52[1] },
            { label: "No answer", data: questao_52[2] },
        ];
    } else if (questao == "#questao53") {
        return [
            { label: "Every school day", data: questao_53[0] },
            { label: "Once a week", data: questao_53[1] },
            { label: "Twice a week", data: questao_53[2] },
            { label: "Three or more times a week", data: questao_53[3] },
            { label: "Once a month", data: questao_53[4] },
            { label: "Twice a month", data: questao_53[5] },
            { label: "Once every two months", data: questao_53[6] },
            { label: "Once in three months", data: questao_53[7] },
            { label: "Once a semester", data: questao_53[8] },
            { label: "Once a year", data: questao_53[9] },
            { label: "No answer", data: questao_53[10] },
        ];
    } else if (questao == "#questao54") {
        return [
            { label: "Yes", data: questao_54[0] },
            { label: "No", data: questao_54[1] },
            { label: "No answer", data: questao_54[2] },
        ];
    } else if (questao == "#questao55") {
        return [
            { label: "Every school day", data: questao_55[0] },
            { label: "Once a week", data: questao_55[1] },
            { label: "Twice a week", data: questao_55[2] },
            { label: "Three or more times a week", data: questao_55[3] },
            { label: "Once a month", data: questao_55[4] },
            { label: "Twice a month", data: questao_55[5] },
            { label: "Once every two months", data: questao_55[6] },
            { label: "Once in three months", data: questao_55[7] },
            { label: "Once a semester", data: questao_55[8] },
            { label: "Once a year", data: questao_55[9] },
            { label: "No answer", data: questao_55[10] },
        ];
    } else if (questao == "#questao56") {
        return [
            { label: "Yes", data: questao_56[0] },
            { label: "No", data: questao_56[1] },
            { label: "No answer", data: questao_56[2] },
        ];
    } else if (questao == "#questao57") {
        return [
            { label: "Every school day", data: questao_57[0] },
            { label: "Once a week", data: questao_57[1] },
            { label: "Twice a week", data: questao_57[2] },
            { label: "Three or more times a week", data: questao_57[3] },
            { label: "Once a month", data: questao_57[4] },
            { label: "Twice a month", data: questao_57[5] },
            { label: "Once every two months", data: questao_57[6] },
            { label: "Once in three months", data: questao_57[7] },
            { label: "Once a semester", data: questao_57[8] },
            { label: "Once a year", data: questao_57[9] },
            { label: "No answer", data: questao_57[10] },
        ];
    } else if (questao == "#questao58") {
        return [
            { label: "Yes", data: questao_58[0] },
            { label: "No", data: questao_58[1] },
            { label: "No answer", data: questao_58[2] },
        ];
    } else if (questao == "#questao59") {
        return [
            { label: "Yes", data: questao_59[0] },
            { label: "No", data: questao_59[1] },
            { label: "No answer", data: questao_59[2] },
        ];
    } else if (questao == "#questao60") {
        return [
            { label: "Yes", data: questao_60[0] },
            { label: "No", data: questao_60[1] },
            { label: "No answer", data: questao_60[2] },
        ];
    } else if (questao == "#questao61") {
        return [
            { label: "Yes", data: questao_61[0] },
            { label: "No", data: questao_61[1] },
            { label: "No answer", data: questao_61[2] },
        ];
    } else if (questao == "#questao62") {
        return [
            { label: "Yes", data: questao_62[0] },
            { label: "No", data: questao_62[1] },
            { label: "No answer", data: questao_62[2] },
        ];
    } else if (questao == "#questao63") {
        return [
            { label: "Monthly", data: questao_63[0] },
            { label: "Bimonthly", data: questao_63[1] },
            { label: "Quarterly", data: questao_63[2] },
            { label: "Once a year", data: questao_63[3] },
            { label: "No answer", data: questao_63[4] },
        ];
    } else if (questao == "#questao64") {
        return [
            { label: "Yes", data: questao_64[0] },
            { label: "No", data: questao_64[1] },
            { label: "No answer", data: questao_64[2] },
        ];
    } else if (questao == "#questao65") {
        return [
            { label: "Yes", data: questao_65[0] },
            { label: "No", data: questao_65[1] },
            { label: "No answer", data: questao_65[2] },
        ];
    } else if (questao == "#questao66") {
        return [
            { label: "Not once", data: questao_66[0] },
            { label: "Rarely", data: questao_66[1] },
            { label: "Sometimes", data: questao_66[2] },
            { label: "Most of the time", data: questao_66[3] },
            { label: "In every period", data: questao_66[4] },
            { label: "No answer", data: questao_66[5] },
        ];
    } else if (questao == "#questao67") {
        return [
            { label: "Not once", data: questao_67[0] },
            { label: "1 time", data: questao_67[1] },
            { label: "2 to 4 times", data: questao_67[2] },
            { label: "5 or more times", data: questao_67[3] },
            { label: "No answer", data: questao_67[4] },
        ];
    } else if (questao == "#questao68") {
        return [
            { label: "Yes", data: questao_68[0] },
            { label: "No", data: questao_68[1] },
            { label: "No answer", data: questao_68[2] },
        ];
    } else if (questao == "#questao69") {
        return [
            { label: "Yes", data: questao_69[0] },
            { label: "No", data: questao_69[1] },
            { label: "No answer", data: questao_69[2] },
        ];
    } else if (questao == "#questao70") {
        return [
            { label: "2013", data: questao_70[0] },
            { label: "2014", data: questao_70[1] },
            { label: "2015", data: questao_70[2] },
            { label: "2016", data: questao_70[3] },
            { label: "2017", data: questao_70[4] },
            { label: "2018", data: questao_70[5] },
            { label: "Don’t know", data: questao_70[6] },
            { label: "No answer", data: questao_70[7] },
        ];
    } else if (questao == "#questao71") {
        return [
            { label: "Yes", data: questao_71[0] },
            { label: "No", data: questao_71[1] },
            { label: "No answer", data: questao_71[2] },
        ];
    } else if (questao == "#questao72") {
        return [
            { label: "Yes", data: questao_72[0] },
            { label: "No", data: questao_72[1] },
            { label: "No answer", data: questao_72[2] },
        ];
    } else if (questao == "#questao73") {
        return [
            { label: "Yes", data: questao_73[0] },
            { label: "No", data: questao_73[1] },
            { label: "No answer", data: questao_73[2] },
        ];
    } else if (questao == "#questao74") {
        return [
            { label: "Yes", data: questao_74[0] },
            { label: "No", data: questao_74[1] },
            { label: "No answer", data: questao_74[2] },
        ];
    } else if (questao == "#questao75") {
        return [
            { label: "Yes", data: questao_75[0] },
            { label: "No", data: questao_75[1] },
            { label: "No answer", data: questao_75[2] },
        ];
    } else if (questao == "#questao76") {
        return [
            { label: "Yes", data: questao_76[0] },
            { label: "No", data: questao_76[1] },
            { label: "No answer", data: questao_76[2] },
        ];
    } else if (questao == "#questao77") {
        return [
            { label: "Yes", data: questao_77[0] },
            { label: "No", data: questao_77[1] },
            { label: "No answer", data: questao_77[2] },
        ];
    } else if (questao == "#questao78") {
        return [
            { label: "Yes", data: questao_78[0] },
            { label: "No", data: questao_78[1] },
            { label: "No answer", data: questao_78[2] },
        ];
    } else if (questao == "#questao79") {
        return [
            { label: "Yes", data: questao_79[0] },
            { label: "No", data: questao_79[1] },
            { label: "No answer", data: questao_79[2] },
        ];
    } else if (questao == "#questao80") {
        return [
            { label: "Yes", data: questao_80[0] },
            { label: "No", data: questao_80[1] },
            { label: "No answer", data: questao_80[2] },
        ];
    } else if (questao == "#questao81") {
        return [
            { label: "Yes", data: questao_81[0] },
            { label: "No", data: questao_81[1] },
            { label: "No answer", data: questao_81[2] },
        ];
    } else if (questao == "#questao82") {
        return [
            { label: "Yes", data: questao_82[0] },
            { label: "No", data: questao_82[1] },
            { label: "No answer", data: questao_82[2] },
        ];
    } else if (questao == "#questao83") {
        return [
            { label: "Yes", data: questao_83[0] },
            { label: "No", data: questao_83[1] },
            { label: "No answer", data: questao_83[2] },
        ];
    } else if (questao == "#questao84") {
        return [
            { label: "Yes", data: questao_84[0] },
            { label: "No", data: questao_84[1] },
            { label: "No answer", data: questao_84[2] },
        ];
    }
}

document.getElementById("baixa-grafico-1").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao1')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-2").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao2')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-3").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao3')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-4").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao4')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-5").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao5')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-6").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao6')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-7").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao7')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-8").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao8')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-9").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao9')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-10").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao10')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-11").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao11')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-12").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao12')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-13").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao13')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-14").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao14')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-15").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao15')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-16").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao16')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-17").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao17')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-18").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao18')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-19").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao19')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-20").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao20')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-21").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao21')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-22").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao22')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-23").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao23')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-24").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao24')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-25").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao25')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-26").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao26')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-27").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao27')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-28").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao28')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-29").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao29')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-30").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao30')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-31").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao31')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-32").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao32')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-33").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao33')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-34").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao34')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-35").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao35')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-36").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao36')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-37").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao37')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-38").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao38')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-39").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao39')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-40").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao40')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-41").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao41')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-42").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao42')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-43").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao43')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-44").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao44')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-45").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao45')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-46").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao46')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-47").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao47')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-48").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao48')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-49").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao49')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-50").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao50')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-51").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao51')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-52").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao52')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-53").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao53')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-54").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao54')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-55").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao55')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-56").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao56')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-57").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao57')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-58").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao58')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-59").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao59')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-60").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao60')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-61").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao61')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-62").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao62')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-63").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao63')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-64").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao64')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-65").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao65')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-66").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao66')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-67").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao67')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-68").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao68')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-69").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao69')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-70").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao70')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-71").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao71')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-72").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao72')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-73").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao73')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-74").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao74')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-75").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao75')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-76").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao76')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-77").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao77')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-78").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao78')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-79").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao79')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-80").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao80')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-81").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao81')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-82").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao82')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-83").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao83')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

document.getElementById("baixa-grafico-84").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao84')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'graph.png');
    });
});

function baixaImagem(uri, filename) {
    var link = document.createElement('a');
    
    if (typeof link.download === 'string') {
        link.href = uri;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    } else {
        window.open(uri);
    }
}
