// Funções para criação de gráficos

document.addEventListener("DOMContentLoaded", function() {
    criaGraficoQuestao("#questao1", carregaDados("#questao1"));
    criaGraficoQuestao("#questao2", carregaDados("#questao2"));
    criaGraficoQuestao("#questao3", carregaDados("#questao3"));
    criaGraficoQuestao("#questao4", carregaDados("#questao4"));
    criaGraficoQuestao("#questao5", carregaDados("#questao5"));
    criaGraficoQuestao("#questao6", carregaDados("#questao6"));
    criaGraficoQuestao("#questao7", carregaDados("#questao7"));
    criaGraficoQuestao("#questao8", carregaDados("#questao8"));
    criaGraficoQuestao("#questao9", carregaDados("#questao9"));
    criaGraficoQuestao("#questao10", carregaDados("#questao10"));
    criaGraficoQuestao("#questao11", carregaDados("#questao11"));
    criaGraficoQuestao("#questao12", carregaDados("#questao12"));
    criaGraficoQuestao("#questao13", carregaDados("#questao13"));
    criaGraficoQuestao("#questao14", carregaDados("#questao14"));
    criaGraficoQuestao("#questao15", carregaDados("#questao15"));
    criaGraficoQuestao("#questao16", carregaDados("#questao16"));
    criaGraficoQuestao("#questao17", carregaDados("#questao17"));
    criaGraficoQuestao("#questao18", carregaDados("#questao18"));
    criaGraficoQuestao("#questao19", carregaDados("#questao19"));
    criaGraficoQuestao("#questao20", carregaDados("#questao20"));
    criaGraficoQuestao("#questao21", carregaDados("#questao21"));
    criaGraficoQuestao("#questao22", carregaDados("#questao22"));
    criaGraficoQuestao("#questao23", carregaDados("#questao23"));
    criaGraficoQuestao("#questao24", carregaDados("#questao24"));
    criaGraficoQuestao("#questao25", carregaDados("#questao25"));
    criaGraficoQuestao("#questao26", carregaDados("#questao26"));
    criaGraficoQuestao("#questao27", carregaDados("#questao27"));
    criaGraficoQuestao("#questao28", carregaDados("#questao28"));
    criaGraficoQuestao("#questao29", carregaDados("#questao29"));
    criaGraficoQuestao("#questao30", carregaDados("#questao30"));
    criaGraficoQuestao("#questao31", carregaDados("#questao31"));
    criaGraficoQuestao("#questao32", carregaDados("#questao32"));
    criaGraficoQuestao("#questao33", carregaDados("#questao33"));
    criaGraficoQuestao("#questao34", carregaDados("#questao34"));
    criaGraficoQuestao("#questao35", carregaDados("#questao35"));
    criaGraficoQuestao("#questao36", carregaDados("#questao36"));
    criaGraficoQuestao("#questao37", carregaDados("#questao37"));
    criaGraficoQuestao("#questao38", carregaDados("#questao38"));
    criaGraficoQuestao("#questao39", carregaDados("#questao39"));
    criaGraficoQuestao("#questao40", carregaDados("#questao40"));
    criaGraficoQuestao("#questao41", carregaDados("#questao41"));
    criaGraficoQuestao("#questao42", carregaDados("#questao42"));
    criaGraficoQuestao("#questao43", carregaDados("#questao43"));
    criaGraficoQuestao("#questao44", carregaDados("#questao44"));
    criaGraficoQuestao("#questao45", carregaDados("#questao45"));
    criaGraficoQuestao("#questao46", carregaDados("#questao46"));
    criaGraficoQuestao("#questao47", carregaDados("#questao47"));
    criaGraficoQuestao("#questao48", carregaDados("#questao48"));
    criaGraficoQuestao("#questao49", carregaDados("#questao49"));
    criaGraficoQuestao("#questao50", carregaDados("#questao50"));
    criaGraficoQuestao("#questao51", carregaDados("#questao51"));
    criaGraficoQuestao("#questao52", carregaDados("#questao52"));
    criaGraficoQuestao("#questao53", carregaDados("#questao53"));
    criaGraficoQuestao("#questao54", carregaDados("#questao54"));
    criaGraficoQuestao("#questao55", carregaDados("#questao55"));
    criaGraficoQuestao("#questao56", carregaDados("#questao56"));
    criaGraficoQuestao("#questao57", carregaDados("#questao57"));
    criaGraficoQuestao("#questao58", carregaDados("#questao58"));
    criaGraficoQuestao("#questao59", carregaDados("#questao59"));
    criaGraficoQuestao("#questao60", carregaDados("#questao60"));
    criaGraficoQuestao("#questao61", carregaDados("#questao61"));
    criaGraficoQuestao("#questao62", carregaDados("#questao62"));
    criaGraficoQuestao("#questao63", carregaDados("#questao63"));
    criaGraficoQuestao("#questao64", carregaDados("#questao64"));
    criaGraficoQuestao("#questao65", carregaDados("#questao65"));
    criaGraficoQuestao("#questao66", carregaDados("#questao66"));
    criaGraficoQuestao("#questao67", carregaDados("#questao67"));
    criaGraficoQuestao("#questao68", carregaDados("#questao68"));
    criaGraficoQuestao("#questao69", carregaDados("#questao69"));
    criaGraficoQuestao("#questao70", carregaDados("#questao70"));
    criaGraficoQuestao("#questao71", carregaDados("#questao71"));
    criaGraficoQuestao("#questao72", carregaDados("#questao72"));
    criaGraficoQuestao("#questao73", carregaDados("#questao73"));
    criaGraficoQuestao("#questao74", carregaDados("#questao74"));
    criaGraficoQuestao("#questao75", carregaDados("#questao75"));
    criaGraficoQuestao("#questao76", carregaDados("#questao76"));
    criaGraficoQuestao("#questao77", carregaDados("#questao77"));
    criaGraficoQuestao("#questao78", carregaDados("#questao78"));
    criaGraficoQuestao("#questao79", carregaDados("#questao79"));
    criaGraficoQuestao("#questao80", carregaDados("#questao80"));
    criaGraficoQuestao("#questao81", carregaDados("#questao81"));
    criaGraficoQuestao("#questao82", carregaDados("#questao82"));
    criaGraficoQuestao("#questao83", carregaDados("#questao83"));
    criaGraficoQuestao("#questao84", carregaDados("#questao84"));
    criaGraficoQuestao("#questao85", carregaDados("#questao85"));
    criaGraficoQuestao("#questao86", carregaDados("#questao86"));
    criaGraficoQuestao("#questao87", carregaDados("#questao87"));
    criaGraficoQuestao("#questao88", carregaDados("#questao88"));
    criaGraficoQuestao("#questao89", carregaDados("#questao89"));
    criaGraficoQuestao("#questao90", carregaDados("#questao90"));
    criaGraficoQuestao("#questao91", carregaDados("#questao91"));
    criaGraficoQuestao("#questao92", carregaDados("#questao92"));
    criaGraficoQuestao("#questao93", carregaDados("#questao93"));
    criaGraficoQuestao("#questao94", carregaDados("#questao94"));
    criaGraficoQuestao("#questao95", carregaDados("#questao95"));
    criaGraficoQuestao("#questao96", carregaDados("#questao96"));
    criaGraficoQuestao("#questao97", carregaDados("#questao97"));
    criaGraficoQuestao("#questao98", carregaDados("#questao98"));
    criaGraficoQuestao("#questao99", carregaDados("#questao99"));
    criaGraficoQuestao("#questao100", carregaDados("#questao100"));
    criaGraficoQuestao("#questao101", carregaDados("#questao101"));
    criaGraficoQuestao("#questao102", carregaDados("#questao102"));
    criaGraficoQuestao("#questao103", carregaDados("#questao103"));
    criaGraficoQuestao("#questao104", carregaDados("#questao104"));
    criaGraficoQuestao("#questao105", carregaDados("#questao105"));
    criaGraficoQuestao("#questao106", carregaDados("#questao106"));
    criaGraficoQuestao("#questao107", carregaDados("#questao107"));
    criaGraficoQuestao("#questao108", carregaDados("#questao108"));
    criaGraficoQuestao("#questao109", carregaDados("#questao109"));
    criaGraficoQuestao("#questao110", carregaDados("#questao110"));
    criaGraficoQuestao("#questao111", carregaDados("#questao111"));
    criaGraficoQuestao("#questao112", carregaDados("#questao112"));
    criaGraficoQuestao("#questao113", carregaDados("#questao113"));
    criaGraficoQuestao("#questao114", carregaDados("#questao114"));
    criaGraficoQuestao("#questao115", carregaDados("#questao115"));
    criaGraficoQuestao("#questao116", carregaDados("#questao116"));
    criaGraficoQuestao("#questao117", carregaDados("#questao117"));
    criaGraficoQuestao("#questao118", carregaDados("#questao118"));
    criaGraficoQuestao("#questao119", carregaDados("#questao119"));
    criaGraficoQuestao("#questao120", carregaDados("#questao120"));
    criaGraficoQuestao("#questao121", carregaDados("#questao121"));
    criaGraficoQuestao("#questao122", carregaDados("#questao122"));
    criaGraficoQuestao("#questao123", carregaDados("#questao123"));
    criaGraficoQuestao("#questao124", carregaDados("#questao124"));
    criaGraficoQuestao("#questao125", carregaDados("#questao125"));
    criaGraficoQuestao("#questao126", carregaDados("#questao126"));
    criaGraficoQuestao("#questao127", carregaDados("#questao127"));
    criaGraficoQuestao("#questao128", carregaDados("#questao128"));
    criaGraficoQuestao("#questao129", carregaDados("#questao129"));
    criaGraficoQuestao("#questao130", carregaDados("#questao130"));
    criaGraficoQuestao("#questao131", carregaDados("#questao131"));
    criaGraficoQuestao("#questao132", carregaDados("#questao132"));
    criaGraficoQuestao("#questao133", carregaDados("#questao133"));
    criaGraficoQuestao("#questao134", carregaDados("#questao134"));
    criaGraficoQuestao("#questao135", carregaDados("#questao135"));
    criaGraficoQuestao("#questao136", carregaDados("#questao136"));
    criaGraficoQuestao("#questao137", carregaDados("#questao137"));
    criaGraficoQuestao("#questao138", carregaDados("#questao138"));
    criaGraficoQuestao("#questao139", carregaDados("#questao139"));
    criaGraficoQuestao("#questao140", carregaDados("#questao140"));
    criaGraficoQuestao("#questao141", carregaDados("#questao141"));
    criaGraficoQuestao("#questao142", carregaDados("#questao142"));
    criaGraficoQuestao("#questao143", carregaDados("#questao143"));
    criaGraficoQuestao("#questao144", carregaDados("#questao144"));
    criaGraficoQuestao("#questao145", carregaDados("#questao145"));
    criaGraficoQuestao("#questao146", carregaDados("#questao146"));
});

function criaGraficoQuestao(questao, dados) {
    var data = dados;
    
    $.plot($(questao), data, { 
        series: {
            pie: {
                show: true,
                radius: 1,
                label: {
                    show: true,
                    radius: 0.9,
                    formatter: function (label, series) {
                        return '<div class="flot-pie-label">' + Math.round(series.percent) +'% (' + series.data[0][1] + ')</div>';
                    },
                    background: { 
                        opacity: 0.5,
                        color: '#000000'
                    }
                }
            }
        },
        grid: {
            hoverable: true
        },
        tooltip: true,
        tooltipOpts: {
            content: "%s: %p.0% (%y.0)",
        },
    });
}

function carregaDados(questao) {
    if (questao == "#questao1") {
        return [
            { label: "Ensino Fundamental", data: questao_1[0] },
            { label: "Ensino Médio", data: questao_1[1] },
            { label: "Ensino Médio Técnico", data: questao_1[2] },
            { label: "Ensino Superior", data: questao_1[3] },
            { label: "Pós-graduação", data: questao_1[4] },
            { label: "Não sei", data: questao_1[5] },
            { label: "Sem resposta", data: questao_1[6] },
        ];
    } else if (questao == "#questao2") {
        return [
            { label: "Somente continuar estudando", data: questao_2[0] },
            { label: "Somente trabalhar", data: questao_2[1] },
            { label: "Continuar estudando e trabalhar", data: questao_2[2] },
            { label: "Seguir outro plano", data: questao_2[3] },
            { label: "Não sei", data: questao_2[4] },
            { label: "Sem resposta", data: questao_2[5] },
        ];
    } else if(questao == '#questao3') {
        return [
            { label: "Sim", data: questao_3[0] },
            { label: "Não", data: questao_3[1] },
            { label: "Sem resposta", data: questao_3[2] },
        ];
    } else if(questao == '#questao4') {
        return [
            { label: "Sim", data: questao_4[0] },
            { label: "Não", data: questao_4[1] },
            { label: "Sem resposta", data: questao_4[2] },
        ];
    } else if(questao == '#questao5') {
        return [
            { label: "1 pessoa (moro sozinho)", data: questao_5[0] },
            { label: "2 pessoas", data: questao_5[1] },
            { label: "3 pessoas", data: questao_5[2] },
            { label: "4 pessoas", data: questao_5[3] },
            { label: "5 pessoas", data: questao_5[4] },
            { label: "6 pessoas", data: questao_5[5] },
            { label: "7 pessoas", data: questao_5[6] },
            { label: "8 pessoas", data: questao_5[7] },
            { label: "9 pessoas", data: questao_5[8] },
            { label: "10 pessoas ou mais", data: questao_5[9] },
            { label: "Sem resposta", data: questao_5[10] },
        ];
    } else if(questao == '#questao6') {
        return [
            { label: "Sim", data: questao_6[0] },
            { label: "Não", data: questao_6[1] },
            { label: "Sem resposta", data: questao_6[2] },
        ];
    } else if(questao == '#questao7') {
        return [
            { label: "Sim", data: questao_7[0] },
            { label: "Não", data: questao_7[1] },
            { label: "Sem resposta", data: questao_7[2] },
        ];
    } else if(questao == '#questao8') {
        return [
            { label: "Sim", data: questao_8[0] },
            { label: "Não", data: questao_8[1] },
            { label: "Sem resposta", data: questao_8[2] },
        ];
    } else if(questao == '#questao9') {
        return [
            { label: "Sim", data: questao_9[0] },
            { label: "Não", data: questao_9[1] },
            { label: "Sem resposta", data: questao_9[2] },
        ];
    } else if(questao == '#questao10') {
        return [
            { label: "Sim", data: questao_10[0] },
            { label: "Não", data: questao_10[1] },
            { label: "Sem resposta", data: questao_10[2] },
        ];
    } else if(questao == '#questao11') {
        return [
            { label: "Sim", data: questao_11[0] },
            { label: "Não", data: questao_11[1] },
            { label: "Sem resposta", data: questao_11[2] },
        ];
    } else if(questao == '#questao12') {
        return [
            { label: "Não tem banheiro com chuveiro dentro da minha casa", data: questao_12[0] },
            { label: "1 banheiro", data: questao_12[1] },
            { label: "2 banheiros", data: questao_12[2] },
            { label: "3 banheiros", data: questao_12[3] },
            { label: "4 banheiros ou mais", data: questao_12[4] },
            { label: "Sem resposta", data: questao_12[5] },
        ];
    } else if(questao == '#questao13') {
        return [
            { label: "Sim", data: questao_13[0] },
            { label: "Não", data: questao_13[1] },
            { label: "Sem resposta", data: questao_13[2] },
        ];
    } else if(questao == '#questao14') {
        return [
            { label: "1 a 2 dias por semana", data: questao_14[0] },
            { label: "3 ou mais dias por semana.", data: questao_14[1] },
            { label: "Sem resposta", data: questao_14[2] },
        ];
    } else if(questao == '#questao15') {
        return [
            { label: "Minha mãe não estudou", data: questao_15[0] },
            { label: "Minha mãe começou o ensino fundamental ou 1o grau, mas não terminou", data: questao_15[1] },
            { label: "Minha mãe terminou o ensino fundamental ou 1o grau", data: questao_15[2] },
            { label: "Minha mãe começou o ensino médio ou 2o grau, mas não terminou", data: questao_15[3] },
            { label: "Minha mãe terminou o ensino médio ou 2o grau", data: questao_15[4] },
            { label: "Minha mãe começou a faculdade (ensino superior), mas não terminou", data: questao_15[5] },
            { label: "Minha mãe terminou a faculdade (ensino superior)", data: questao_15[6] },
            { label: "Não sei", data: questao_15[7] },
            { label: "Sem resposta", data: questao_15[8] },
        ];
    } else if(questao == '#questao16') {
        return [
            { label: "Sim", data: questao_16[0] },
            { label: "Não", data: questao_16[1] },
            { label: "Sem resposta", data: questao_16[2] },
        ];
    } else if(questao == '#questao17') {
        return [
            { label: "Sim", data: questao_17[0] },
            { label: "Não", data: questao_17[1] },
            { label: "Sem resposta", data: questao_17[2] },
        ];
    } else if(questao == '#questao18') {
        return [
            { label: "Sim", data: questao_18[0] },
            { label: "Não", data: questao_18[1] },
            { label: "Sem resposta", data: questao_18[2] },
        ];
    } else if(questao == '#questao19') {
        return [
            { label: "Sim, todos os dias", data: questao_19[0] },
            { label: "Sim, 5 a 6 dias por semana", data: questao_19[1] },
            { label: "Sim, 3 a 4 dias por semana", data: questao_19[2] },
            { label: "Sim, 1 a 2 dias por semana", data: questao_19[3] },
            { label: "Raramente", data: questao_19[4] },
            { label: "Não", data: questao_19[5] },
            { label: "Sem resposta", data: questao_19[6] },
        ];
    } else if(questao == '#questao20') {
        return [
            { label: "Sim, todos os dias", data: questao_20[0] },
            { label: "Sim, 5 a 6 dias por semana", data: questao_20[1] },
            { label: "Sim, 3 a 4 dias por semana", data: questao_20[2] },
            { label: "Sim, 1 a 2 dias por semana", data: questao_20[3] },
            { label: "Raramente", data: questao_20[4] },
            { label: "Não", data: questao_20[5] },
            { label: "Sem resposta", data: questao_20[6] },
        ];
    } else if(questao == '#questao21') {
        return [
            { label: "Sim, todos os dias", data: questao_21[0] },
            { label: "Sim, 5 a 6 dias por semana", data: questao_21[1] },
            { label: "Sim, 3 a 4 dias por semana", data: questao_21[2] },
            { label: "Sim, 1 a 2 dias por semana", data: questao_21[3] },
            { label: "Raramente", data: questao_21[4] },
            { label: "Não", data: questao_21[5] },
            { label: "Sem resposta", data: questao_21[6] },
        ];
    } else if(questao == '#questao22') {
        return [
            { label: "Sim", data: questao_22[0] },
            { label: "Não", data: questao_22[1] },
            { label: "Não sei", data: questao_22[2] },
            { label: "Sem resposta", data: questao_22[3] },
        ];
    } else if(questao == '#questao23') {
        return [
            { label: "Sim, todos os dias", data: questao_23[0] },
            { label: "Sim, 3 a 4 dias por semana", data: questao_23[1] },
            { label: "Sim, 1 a 2 dias por semana", data: questao_23[2] },
            { label: "Raramente", data: questao_23[3] },
            { label: "Não", data: questao_23[4] },
            { label: "Sem resposta", data: questao_23[5] },
        ];
    } else if(questao == '#questao24') {
        return [
            { label: "Nunca", data: questao_24[0] },
            { label: "Raramente", data: questao_24[1] },
            { label: "Às vezes", data: questao_24[2] },
            { label: "Na maior parte das vezes", data: questao_24[3] },
            { label: "Sempre", data: questao_24[4] },
            { label: "Sem resposta", data: questao_24[5] },
        ];
    } else if(questao == '#questao25') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_25[0] },
            { label: "1 a 3 vezes por mês", data: questao_25[1] },
            { label: "1 vez por semana", data: questao_25[2] },
            { label: "2 a 4 vezes por semana", data: questao_25[3] },
            { label: "6 a 8 vezes por semana", data: questao_25[4] },
            { label: "1 vez por dia", data: questao_25[5] },
            { label: "2 a 3 vezes por dia", data: questao_25[6] },
            { label: "4 a 6 vezes por dia", data: questao_25[7] },
            { label: "Mais de 8 vezes por dia", data: questao_25[8] },
            { label: "Sem resposta", data: questao_25[9] },
        ];
    } else if(questao == '#questao26') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_26[0] },
            { label: "1 a 3 vezes por mês", data: questao_26[1] },
            { label: "1 vez por semana", data: questao_26[2] },
            { label: "2 a 4 vezes por semana", data: questao_26[3] },
            { label: "6 a 8 vezes por semana", data: questao_26[4] },
            { label: "1 vez por dia", data: questao_26[5] },
            { label: "2 a 3 vezes por dia", data: questao_26[6] },
            { label: "4 a 6 vezes por dia", data: questao_26[7] },
            { label: "Mais de 8 vezes por dia", data: questao_26[8] },
            { label: "Sem resposta", data: questao_26[9] },
        ];
    } else if(questao == '#questao27') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_27[0] },
            { label: "1 a 3 vezes por mês", data: questao_27[1] },
            { label: "1 vez por semana", data: questao_27[2] },
            { label: "2 a 4 vezes por semana", data: questao_27[3] },
            { label: "6 a 8 vezes por semana", data: questao_27[4] },
            { label: "1 vez por dia", data: questao_27[5] },
            { label: "2 a 3 vezes por dia", data: questao_27[6] },
            { label: "4 a 6 vezes por dia", data: questao_27[7] },
            { label: "Mais de 8 vezes por dia", data: questao_27[8] },
            { label: "Sem resposta", data: questao_27[9] },
        ];
    } else if(questao == '#questao28') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_28[0] },
            { label: "1 a 3 vezes por mês", data: questao_28[1] },
            { label: "1 vez por semana", data: questao_28[2] },
            { label: "2 a 4 vezes por semana", data: questao_28[3] },
            { label: "6 a 8 vezes por semana", data: questao_28[4] },
            { label: "1 vez por dia", data: questao_28[5] },
            { label: "2 a 3 vezes por dia", data: questao_28[6] },
            { label: "4 a 6 vezes por dia", data: questao_28[7] },
            { label: "Mais de 8 vezes por dia", data: questao_28[8] },
            { label: "Sem resposta", data: questao_28[9] },
        ];
    } else if(questao == '#questao29') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_29[0] },
            { label: "1 a 3 vezes por mês", data: questao_29[1] },
            { label: "1 vez por semana", data: questao_29[2] },
            { label: "2 a 4 vezes por semana", data: questao_29[3] },
            { label: "6 a 8 vezes por semana", data: questao_29[4] },
            { label: "1 vez por dia", data: questao_29[5] },
            { label: "2 a 3 vezes por dia", data: questao_29[6] },
            { label: "4 a 6 vezes por dia", data: questao_29[7] },
            { label: "Mais de 8 vezes por dia", data: questao_29[8] },
            { label: "Sem resposta", data: questao_29[9] },
        ];
    } else if(questao == '#questao30') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_30[0] },
            { label: "1 a 3 vezes por mês", data: questao_30[1] },
            { label: "1 vez por semana", data: questao_30[2] },
            { label: "2 a 4 vezes por semana", data: questao_30[3] },
            { label: "6 a 8 vezes por semana", data: questao_30[4] },
            { label: "1 vez por dia", data: questao_30[5] },
            { label: "2 a 3 vezes por dia", data: questao_30[6] },
            { label: "4 a 6 vezes por dia", data: questao_30[7] },
            { label: "Mais de 8 vezes por dia", data: questao_30[8] },
            { label: "Sem resposta", data: questao_30[9] },
        ];
    } else if(questao == '#questao31') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_31[0] },
            { label: "1 a 3 vezes por mês", data: questao_31[1] },
            { label: "1 vez por semana", data: questao_31[2] },
            { label: "2 a 4 vezes por semana", data: questao_31[3] },
            { label: "6 a 8 vezes por semana", data: questao_31[4] },
            { label: "1 vez por dia", data: questao_31[5] },
            { label: "2 a 3 vezes por dia", data: questao_31[6] },
            { label: "4 a 6 vezes por dia", data: questao_31[7] },
            { label: "Mais de 8 vezes por dia", data: questao_31[8] },
            { label: "Sem resposta", data: questao_31[9] },
        ];
    } else if(questao == '#questao32') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_32[0] },
            { label: "1 a 3 vezes por mês", data: questao_32[1] },
            { label: "1 vez por semana", data: questao_32[2] },
            { label: "2 a 4 vezes por semana", data: questao_32[3] },
            { label: "6 a 8 vezes por semana", data: questao_32[4] },
            { label: "1 vez por dia", data: questao_32[5] },
            { label: "2 a 3 vezes por dia", data: questao_32[6] },
            { label: "4 a 6 vezes por dia", data: questao_32[7] },
            { label: "Mais de 8 vezes por dia", data: questao_32[8] },
            { label: "Sem resposta", data: questao_32[9] },
        ];
    } else if(questao == '#questao33') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_33[0] },
            { label: "1 a 3 vezes por mês", data: questao_33[1] },
            { label: "1 vez por semana", data: questao_33[2] },
            { label: "2 a 4 vezes por semana", data: questao_33[3] },
            { label: "6 a 8 vezes por semana", data: questao_33[4] },
            { label: "1 vez por dia", data: questao_33[5] },
            { label: "2 a 3 vezes por dia", data: questao_33[6] },
            { label: "4 a 6 vezes por dia", data: questao_33[7] },
            { label: "Mais de 8 vezes por dia", data: questao_33[8] },
            { label: "Sem resposta", data: questao_33[9] },
        ];
    } else if(questao == '#questao34') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_34[0] },
            { label: "1 a 3 vezes por mês", data: questao_34[1] },
            { label: "1 vez por semana", data: questao_34[2] },
            { label: "2 a 4 vezes por semana", data: questao_34[3] },
            { label: "6 a 8 vezes por semana", data: questao_34[4] },
            { label: "1 vez por dia", data: questao_34[5] },
            { label: "2 a 3 vezes por dia", data: questao_34[6] },
            { label: "4 a 6 vezes por dia", data: questao_34[7] },
            { label: "Mais de 8 vezes por dia", data: questao_34[8] },
            { label: "Sem resposta", data: questao_34[9] },
        ];
    } else if(questao == '#questao35') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_35[0] },
            { label: "1 a 3 vezes por mês", data: questao_35[1] },
            { label: "1 vez por semana", data: questao_35[2] },
            { label: "2 a 4 vezes por semana", data: questao_35[3] },
            { label: "6 a 8 vezes por semana", data: questao_35[4] },
            { label: "1 vez por dia", data: questao_35[5] },
            { label: "2 a 3 vezes por dia", data: questao_35[6] },
            { label: "4 a 6 vezes por dia", data: questao_35[7] },
            { label: "Mais de 8 vezes por dia", data: questao_35[8] },
            { label: "Sem resposta", data: questao_35[9] },
        ];
    } else if(questao == '#questao36') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_36[0] },
            { label: "1 a 3 vezes por mês", data: questao_36[1] },
            { label: "1 vez por semana", data: questao_36[2] },
            { label: "2 a 4 vezes por semana", data: questao_36[3] },
            { label: "6 a 8 vezes por semana", data: questao_36[4] },
            { label: "1 vez por dia", data: questao_36[5] },
            { label: "2 a 3 vezes por dia", data: questao_36[6] },
            { label: "4 a 6 vezes por dia", data: questao_36[7] },
            { label: "Mais de 8 vezes por dia", data: questao_36[8] },
            { label: "Sem resposta", data: questao_36[9] },
        ];
    } else if(questao == '#questao37') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_37[0] },
            { label: "1 a 3 vezes por mês", data: questao_37[1] },
            { label: "1 vez por semana", data: questao_37[2] },
            { label: "2 a 4 vezes por semana", data: questao_37[3] },
            { label: "6 a 8 vezes por semana", data: questao_37[4] },
            { label: "1 vez por dia", data: questao_37[5] },
            { label: "2 a 3 vezes por dia", data: questao_37[6] },
            { label: "4 a 6 vezes por dia", data: questao_37[7] },
            { label: "Mais de 8 vezes por dia", data: questao_37[8] },
            { label: "Sem resposta", data: questao_37[9] },
        ];
    } else if(questao == '#questao38') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_38[0] },
            { label: "1 a 3 vezes por mês", data: questao_38[1] },
            { label: "1 vez por semana", data: questao_38[2] },
            { label: "2 a 4 vezes por semana", data: questao_38[3] },
            { label: "6 a 8 vezes por semana", data: questao_38[4] },
            { label: "1 vez por dia", data: questao_38[5] },
            { label: "2 a 3 vezes por dia", data: questao_38[6] },
            { label: "4 a 6 vezes por dia", data: questao_38[7] },
            { label: "Mais de 8 vezes por dia", data: questao_38[8] },
            { label: "Sem resposta", data: questao_38[9] },
        ];
    } else if(questao == '#questao39') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_39[0] },
            { label: "1 a 3 vezes por mês", data: questao_39[1] },
            { label: "1 vez por semana", data: questao_39[2] },
            { label: "2 a 4 vezes por semana", data: questao_39[3] },
            { label: "6 a 8 vezes por semana", data: questao_39[4] },
            { label: "1 vez por dia", data: questao_39[5] },
            { label: "2 a 3 vezes por dia", data: questao_39[6] },
            { label: "4 a 6 vezes por dia", data: questao_39[7] },
            { label: "Mais de 8 vezes por dia", data: questao_39[8] },
            { label: "Sem resposta", data: questao_39[9] },
        ];
    } else if(questao == '#questao40') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_40[0] },
            { label: "1 a 3 vezes por mês", data: questao_40[1] },
            { label: "1 vez por semana", data: questao_40[2] },
            { label: "2 a 4 vezes por semana", data: questao_40[3] },
            { label: "6 a 8 vezes por semana", data: questao_40[4] },
            { label: "1 vez por dia", data: questao_40[5] },
            { label: "2 a 3 vezes por dia", data: questao_40[6] },
            { label: "4 a 6 vezes por dia", data: questao_40[7] },
            { label: "Mais de 8 vezes por dia", data: questao_40[8] },
            { label: "Sem resposta", data: questao_40[9] },
        ];
    } else if(questao == '#questao41') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_41[0] },
            { label: "1 a 3 vezes por mês", data: questao_41[1] },
            { label: "1 vez por semana", data: questao_41[2] },
            { label: "2 a 4 vezes por semana", data: questao_41[3] },
            { label: "6 a 8 vezes por semana", data: questao_41[4] },
            { label: "1 vez por dia", data: questao_41[5] },
            { label: "2 a 3 vezes por dia", data: questao_41[6] },
            { label: "4 a 6 vezes por dia", data: questao_41[7] },
            { label: "Mais de 8 vezes por dia", data: questao_41[8] },
            { label: "Sem resposta", data: questao_41[9] },
        ];
    } else if(questao == '#questao42') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_42[0] },
            { label: "1 a 3 vezes por mês", data: questao_42[1] },
            { label: "1 vez por semana", data: questao_42[2] },
            { label: "2 a 4 vezes por semana", data: questao_42[3] },
            { label: "6 a 8 vezes por semana", data: questao_42[4] },
            { label: "1 vez por dia", data: questao_42[5] },
            { label: "2 a 3 vezes por dia", data: questao_42[6] },
            { label: "4 a 6 vezes por dia", data: questao_42[7] },
            { label: "Mais de 8 vezes por dia", data: questao_42[8] },
            { label: "Sem resposta", data: questao_42[9] },
        ];
    } else if(questao == '#questao43') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_43[0] },
            { label: "1 a 3 vezes por mês", data: questao_43[1] },
            { label: "1 vez por semana", data: questao_43[2] },
            { label: "2 a 4 vezes por semana", data: questao_43[3] },
            { label: "6 a 8 vezes por semana", data: questao_43[4] },
            { label: "1 vez por dia", data: questao_43[5] },
            { label: "2 a 3 vezes por dia", data: questao_43[6] },
            { label: "4 a 6 vezes por dia", data: questao_43[7] },
            { label: "Mais de 8 vezes por dia", data: questao_43[8] },
            { label: "Sem resposta", data: questao_43[9] },
        ];
    } else if(questao == '#questao44') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_44[0] },
            { label: "1 a 3 vezes por mês", data: questao_44[1] },
            { label: "1 vez por semana", data: questao_44[2] },
            { label: "2 a 4 vezes por semana", data: questao_44[3] },
            { label: "6 a 8 vezes por semana", data: questao_44[4] },
            { label: "1 vez por dia", data: questao_44[5] },
            { label: "2 a 3 vezes por dia", data: questao_44[6] },
            { label: "4 a 6 vezes por dia", data: questao_44[7] },
            { label: "Mais de 8 vezes por dia", data: questao_44[8] },
            { label: "Sem resposta", data: questao_44[9] },
        ];
    } else if(questao == '#questao45') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_45[0] },
            { label: "1 a 3 vezes por mês", data: questao_45[1] },
            { label: "1 vez por semana", data: questao_45[2] },
            { label: "2 a 4 vezes por semana", data: questao_45[3] },
            { label: "6 a 8 vezes por semana", data: questao_45[4] },
            { label: "1 vez por dia", data: questao_45[5] },
            { label: "2 a 3 vezes por dia", data: questao_45[6] },
            { label: "4 a 6 vezes por dia", data: questao_45[7] },
            { label: "Mais de 8 vezes por dia", data: questao_45[8] },
            { label: "Sem resposta", data: questao_45[9] },
        ];
    } else if(questao == '#questao46') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_46[0] },
            { label: "1 a 3 vezes por mês", data: questao_46[1] },
            { label: "1 vez por semana", data: questao_46[2] },
            { label: "2 a 4 vezes por semana", data: questao_46[3] },
            { label: "6 a 8 vezes por semana", data: questao_46[4] },
            { label: "1 vez por dia", data: questao_46[5] },
            { label: "2 a 3 vezes por dia", data: questao_46[6] },
            { label: "4 a 6 vezes por dia", data: questao_46[7] },
            { label: "Mais de 8 vezes por dia", data: questao_46[8] },
            { label: "Sem resposta", data: questao_46[9] },
        ];
    } else if(questao == '#questao47') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_47[0] },
            { label: "1 a 3 vezes por mês", data: questao_47[1] },
            { label: "1 vez por semana", data: questao_47[2] },
            { label: "2 a 4 vezes por semana", data: questao_47[3] },
            { label: "6 a 8 vezes por semana", data: questao_47[4] },
            { label: "1 vez por dia", data: questao_47[5] },
            { label: "2 a 3 vezes por dia", data: questao_47[6] },
            { label: "4 a 6 vezes por dia", data: questao_47[7] },
            { label: "Mais de 8 vezes por dia", data: questao_47[8] },
            { label: "Sem resposta", data: questao_47[9] },
        ];
    } else if(questao == '#questao48') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_48[0] },
            { label: "1 a 3 vezes por mês", data: questao_48[1] },
            { label: "1 vez por semana", data: questao_48[2] },
            { label: "2 a 4 vezes por semana", data: questao_48[3] },
            { label: "6 a 8 vezes por semana", data: questao_48[4] },
            { label: "1 vez por dia", data: questao_48[5] },
            { label: "2 a 3 vezes por dia", data: questao_48[6] },
            { label: "4 a 6 vezes por dia", data: questao_48[7] },
            { label: "Mais de 8 vezes por dia", data: questao_48[8] },
            { label: "Sem resposta", data: questao_48[9] },
        ];
    } else if(questao == '#questao49') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_49[0] },
            { label: "1 a 3 vezes por mês", data: questao_49[1] },
            { label: "1 vez por semana", data: questao_49[2] },
            { label: "2 a 4 vezes por semana", data: questao_49[3] },
            { label: "6 a 8 vezes por semana", data: questao_49[4] },
            { label: "1 vez por dia", data: questao_49[5] },
            { label: "2 a 3 vezes por dia", data: questao_49[6] },
            { label: "4 a 6 vezes por dia", data: questao_49[7] },
            { label: "Mais de 8 vezes por dia", data: questao_49[8] },
            { label: "Sem resposta", data: questao_49[9] },
        ];
    } else if(questao == '#questao50') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_50[0] },
            { label: "1 a 3 vezes por mês", data: questao_50[1] },
            { label: "1 vez por semana", data: questao_50[2] },
            { label: "2 a 4 vezes por semana", data: questao_50[3] },
            { label: "6 a 8 vezes por semana", data: questao_50[4] },
            { label: "1 vez por dia", data: questao_50[5] },
            { label: "2 a 3 vezes por dia", data: questao_50[6] },
            { label: "4 a 6 vezes por dia", data: questao_50[7] },
            { label: "Mais de 8 vezes por dia", data: questao_50[8] },
            { label: "Sem resposta", data: questao_50[9] },
        ];
    } else if(questao == '#questao51') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_51[0] },
            { label: "1 a 3 vezes por mês", data: questao_51[1] },
            { label: "1 vez por semana", data: questao_51[2] },
            { label: "2 a 4 vezes por semana", data: questao_51[3] },
            { label: "6 a 8 vezes por semana", data: questao_51[4] },
            { label: "1 vez por dia", data: questao_51[5] },
            { label: "2 a 3 vezes por dia", data: questao_51[6] },
            { label: "4 a 6 vezes por dia", data: questao_51[7] },
            { label: "Mais de 8 vezes por dia", data: questao_51[8] },
            { label: "Sem resposta", data: questao_51[9] },
        ];
    } else if(questao == '#questao52') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_52[0] },
            { label: "1 a 3 vezes por mês", data: questao_52[1] },
            { label: "1 vez por semana", data: questao_52[2] },
            { label: "2 a 4 vezes por semana", data: questao_52[3] },
            { label: "6 a 8 vezes por semana", data: questao_52[4] },
            { label: "1 vez por dia", data: questao_52[5] },
            { label: "2 a 3 vezes por dia", data: questao_52[6] },
            { label: "4 a 6 vezes por dia", data: questao_52[7] },
            { label: "Mais de 8 vezes por dia", data: questao_52[8] },
            { label: "Sem resposta", data: questao_52[9] },
        ];
    } else if(questao == '#questao53') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_53[0] },
            { label: "1 a 3 vezes por mês", data: questao_53[1] },
            { label: "1 vez por semana", data: questao_53[2] },
            { label: "2 a 4 vezes por semana", data: questao_53[3] },
            { label: "6 a 8 vezes por semana", data: questao_53[4] },
            { label: "1 vez por dia", data: questao_53[5] },
            { label: "2 a 3 vezes por dia", data: questao_53[6] },
            { label: "4 a 6 vezes por dia", data: questao_53[7] },
            { label: "Mais de 8 vezes por dia", data: questao_53[8] },
            { label: "Sem resposta", data: questao_53[9] },
        ];
    } else if(questao == '#questao54') {
        return [
            { label: "Nunca ou menos de uma vez por mês", data: questao_54[0] },
            { label: "1 a 3 vezes por mês", data: questao_54[1] },
            { label: "1 vez por semana", data: questao_54[2] },
            { label: "2 a 4 vezes por semana", data: questao_54[3] },
            { label: "6 a 8 vezes por semana", data: questao_54[4] },
            { label: "1 vez por dia", data: questao_54[5] },
            { label: "2 a 3 vezes por dia", data: questao_54[6] },
            { label: "4 a 6 vezes por dia", data: questao_54[7] },
            { label: "Mais de 8 vezes por dia", data: questao_54[8] },
            { label: "Sem resposta", data: questao_54[9] },
        ];
    } else if(questao == '#questao55') {
        return [
            { label: "Sim", data: questao_55[0] },
            { label: "Não (neste caso, pule para a questão 58)", data: questao_55[1] },
            { label: "Sem resposta", data: questao_55[2] },
        ];
    } else if(questao == '#questao56') {
        return [
            { label: "Até um mês ou menos", data: questao_56[0] },
            { label: "Até 2 meses;", data: questao_56[1] },
            { label: "Até 3 meses;", data: questao_56[2] },
            { label: "Até 4 meses;", data: questao_56[3] },
            { label: "Até 5 meses;", data: questao_56[4] },
            { label: "Até 6 meses ou mais.", data: questao_56[5] },
            { label: "Sem resposta", data: questao_56[6] },
        ];
    } else if(questao == '#questao57') {
        return [
            { label: "Não. Meu filho ou filha não mamou até 6 meses ou mais", data: questao_57[0] },
            { label: "Até 6 meses de idade;", data: questao_57[1] },
            { label: "Até 7 meses de idade;", data: questao_57[2] },
            { label: "Até 8 meses de idade;", data: questao_57[3] },
            { label: "Até 9 meses de idade;", data: questao_57[4] },
            { label: "Até 10 meses de idade;", data: questao_57[5] },
            { label: "Até 11 meses de idade;", data: questao_57[6] },
            { label: "Até 12 meses de idade;", data: questao_57[7] },
            { label: "Mais de 12 meses até 18 meses de idade;", data: questao_57[8] },
            { label: "Mais de 18 meses até 24 meses de idade.", data: questao_57[9] },
            { label: "Sem resposta", data: questao_57[10] },
        ];
    } else if(questao == '#questao58') {
        return [
            { label: "Sim", data: questao_58[0] },
            { label: "Não", data: questao_58[1] },
            { label: "Sem resposta", data: questao_58[2] },
        ];
    } else if(questao == '#questao59') {
        return [
            { label: "Até um mês ou menos;", data: questao_59[0] },
            { label: "Até 2 meses;", data: questao_59[1] },
            { label: "Até 3 meses;", data: questao_59[2] },
            { label: "Até 4 meses;", data: questao_59[3] },
            { label: "Até 5 meses;", data: questao_59[4] },
            { label: "Até 6 meses ou mais;", data: questao_59[5] },
            { label: "Até 7 meses de idade;", data: questao_59[6] },
            { label: "Até 8 meses de idade;", data: questao_59[7] },
            { label: "Até 9 meses de idade;", data: questao_59[8] },
            { label: "Até 10 meses de idade;", data: questao_59[9] },
            { label: "Até 11 meses de idade;", data: questao_59[10] },
            { label: "Até 12 meses de idade;", data: questao_59[11] },
            { label: "Mais de 12 meses até 18 meses de idade;", data: questao_59[12] },
            { label: "Mais de 18 meses até 24 meses de idade.", data: questao_59[13] },
            { label: "Sem resposta", data: questao_59[14] },
        ];
    } else if(questao == '#questao60') {
        return [
            { label: "Não. Meu filho ou filha não recebeu alimentação mista até os dois anos de idade", data: questao_60[0] },
            { label: "Sim. Leite + papinhas", data: questao_60[1] },
            { label: "Sim. Leite + sopas", data: questao_60[2] },
            { label: "Sim. Leite + frutas", data: questao_60[3] },
            { label: "Sem resposta", data: questao_60[4] },
        ];
    } else if(questao == '#questao61') {
        return [
            { label: "Sim", data: questao_61[0] },
            { label: "Não", data: questao_61[1] },
            { label: "Sem resposta", data: questao_61[2] },
        ];
    } else if(questao == '#questao62') {
        return [
            { label: "Menos de 1 mês", data: questao_62[0] },
            { label: "1 e menos de 2 meses;", data: questao_62[1] },
            { label: "2 e menos de 3 meses", data: questao_62[2] },
            { label: "3 e menos de 4 meses;", data: questao_62[3] },
            { label: "4 e menos de 5 meses;", data: questao_62[4] },
            { label: "5 e menos de 6 meses", data: questao_62[5] },
            { label: "6 e menos de 7 meses;", data: questao_62[6] },
            { label: "7 e menos de 8 meses;", data: questao_62[7] },
            { label: "8 e menos de 9 meses;", data: questao_62[8] },
            { label: "9 e menos de 10 meses", data: questao_62[9] },
            { label: "10 e menos de 11 meses;", data: questao_62[10] },
            { label: "11 e menos de 12 meses;", data: questao_62[11] },
            { label: "12 e menos de 18 meses de idade;", data: questao_62[12] },
            { label: "18 e menos 24 meses de idade.", data: questao_62[13] },
            { label: "Sem resposta", data: questao_62[14] },
        ];
    } else if(questao == '#questao63') {
        return [
            { label: "Nenhum dia nos últimos 7 dias (0 dia)", data: questao_63[0] },
            { label: "1 dia nos últimos 7 dias", data: questao_63[1] },
            { label: "2 dias nos últimos 7 dias", data: questao_63[2] },
            { label: "3 dias nos últimos 7 dias", data: questao_63[3] },
            { label: "4 dias nos últimos 7 dias", data: questao_63[4] },
            { label: "5 dias nos últimos 7 dias", data: questao_63[5] },
            { label: "5 dias mais sábado, nos últimos 7 dias", data: questao_63[6] },
            { label: "5 dias mais sábado e domingo, nos últimos 7 dias", data: questao_63[7] },
            { label: "Sem resposta", data: questao_63[8] },
        ];
    } else if(questao == '#questao64') {
        return [
            { label: "Menos de 10 minutos por dia", data: questao_64[0] },
            { label: "10 a 19 minutos por dia", data: questao_64[1] },
            { label: "20 a 29 minutos por dia", data: questao_64[2] },
            { label: "30 a 39 minutos por dia", data: questao_64[3] },
            { label: "40 a 49 minutos por dia", data: questao_64[4] },
            { label: "50 a 59 minutos por dia", data: questao_64[5] },
            { label: "1 hora ou mais por dia", data: questao_64[6] },
            { label: "Sem resposta", data: questao_64[7] },
        ];
    } else if(questao == '#questao65') {
        return [
            { label: "Nenhum dia nos últimos 7 dias (0 dia)", data: questao_65[0] },
            { label: "1 dia nos últimos 7 dias", data: questao_65[1] },
            { label: "2 dias nos últimos 7 dias", data: questao_65[2] },
            { label: "3 dias nos últimos 7 dias", data: questao_65[3] },
            { label: "4 dias nos últimos 7 dias", data: questao_65[4] },
            { label: "5 dias nos últimos 7 dias", data: questao_65[5] },
            { label: "5 dias mais sábado, nos últimos 7 dias", data: questao_65[6] },
            { label: "5 dias mais sábado e domingo, nos últimos 7 dias", data: questao_65[7] },
            { label: "Sem resposta", data: questao_65[8] },
        ];
    } else if(questao == '#questao66') {
        return [
            { label: "Não fiz aula de educação física na escola nos últimos 7 dias.", data: questao_66[0] },
            { label: "Menos de 10 minutos por dia", data: questao_66[1] },
            { label: "10 a 19 minutos por dia", data: questao_66[2] },
            { label: "20 a 29 minutos por dia", data: questao_66[3] },
            { label: "30 a 39 minutos por dia", data: questao_66[4] },
            { label: "40 a 49 minutos por dia", data: questao_66[5] },
            { label: "50 a 59 minutos por dia", data: questao_66[6] },
            { label: "1 hora ou mais por dia", data: questao_66[7] },
            { label: "Sem resposta", data: questao_66[8] },
        ];
    } else if(questao == '#questao67') {
        return [
            { label: "Nenhum dia nos últimos 7 dias (0 dia)", data: questao_67[0] },
            { label: "1 dia nos últimos 7 dias", data: questao_67[1] },
            { label: "2 dias nos últimos 7 dias", data: questao_67[2] },
            { label: "3 dias nos últimos 7 dias", data: questao_67[3] },
            { label: "4 dias nos últimos 7 dias", data: questao_67[4] },
            { label: "5 dias nos últimos 7 dias", data: questao_67[5] },
            { label: "5 dias mais sábado, nos últimos 7 dias", data: questao_67[6] },
            { label: "5 dias mais sábado e domingo, nos últimos 7 dias", data: questao_67[7] },
            { label: "Sem resposta", data: questao_67[8] },
        ];
    } else if(questao == '#questao68') {
        return [
            { label: "Menos de 10 minutos por dia", data: questao_68[0] },
            { label: "10 a 19 minutos por dia", data: questao_68[1] },
            { label: "20 a 29 minutos por dia", data: questao_68[2] },
            { label: "30 a 39 minutos por dia", data: questao_68[3] },
            { label: "40 a 49 minutos por dia", data: questao_68[4] },
            { label: "50 a 59 minutos por dia", data: questao_68[5] },
            { label: "1 hora ou mais por dia", data: questao_68[6] },
            { label: "Sem resposta", data: questao_68[7] },
        ];
    } else if(questao == '#questao69') {
        return [
            { label: "Nenhum dia nos últimos 7 dias (0 dia)", data: questao_69[0] },
            { label: "1 dia nos últimos 7 dias", data: questao_69[1] },
            { label: "2 dias nos últimos 7 dias", data: questao_69[2] },
            { label: "3 dias nos últimos 7 dias", data: questao_69[3] },
            { label: "4 dias nos últimos 7 dias", data: questao_69[4] },
            { label: "5 dias nos últimos 7 dias", data: questao_69[5] },
            { label: "5 dias mais sábado, nos últimos 7 dias", data: questao_69[6] },
            { label: "5 dias mais sábado e domingo, nos últimos 7 dias", data: questao_69[7] },
            { label: "Sem resposta", data: questao_69[8] },
        ];
    } else if(questao == '#questao70') {
        return [
            { label: "Não faria mesmo assim", data: questao_70[0] },
            { label: "Faria atividade física em alguns dias da semana", data: questao_70[1] },
            { label: "Faria atividade física na maioria dos dias da semana", data: questao_70[2] },
            { label: "Já faço atividade física em alguns dias da semana", data: questao_70[3] },
            { label: "Já faço atividade física na maioria dos dias da semana", data: questao_70[4] },
            { label: "Sem resposta", data: questao_70[5] },
        ];
    } else if(questao == '#questao71') {
        return [
            { label: "Não assisto a TV", data: questao_71[0] },
            { label: "Até 1 hora por dia", data: questao_71[1] },
            { label: "Mais de 1 hora até 2 horas por dia", data: questao_71[2] },
            { label: "Mais de 2 horas até 3 horas por dia", data: questao_71[3] },
            { label: "Mais de 3 horas até 4 horas por dia", data: questao_71[4] },
            { label: "Mais de 4 horas até 5 horas por dia", data: questao_71[5] },
            { label: "Mais de 5 horas até 6 horas por dia", data: questao_71[6] },
            { label: "Mais de 6 horas até 7 horas por dia", data: questao_71[7] },
            { label: "Mais de 7 horas até 8 horas por dia", data: questao_71[8] },
            { label: "Mais de 8 horas por dia", data: questao_71[9] },
            { label: "Sem resposta", data: questao_71[10] },
        ];
    } else if(questao == '#questao72') {
        return [
            { label: "Até 1 hora por dia", data: questao_72[0] },
            { label: "Mais de 1 hora até 2 horas por dia", data: questao_72[1] },
            { label: "Mais de 2 horas até 3 horas por dia", data: questao_72[2] },
            { label: "Mais de 3 horas até 4 horas por dia", data: questao_72[3] },
            { label: "Mais de 4 horas até 5 horas por dia", data: questao_72[4] },
            { label: "Mais de 5 horas até 6 horas por dia", data: questao_72[5] },
            { label: "Mais de 6 horas até 7 horas por dia", data: questao_72[6] },
            { label: "Mais de 7 horas até 8 horas por dia", data: questao_72[7] },
            { label: "Mais de 8 horas por dia", data: questao_72[8] },
            { label: "Sem resposta", data: questao_72[9] },
        ];
    } else if(questao == '#questao73') {
        return [
            { label: "Sim", data: questao_73[0] },
            { label: "Não", data: questao_73[1] },
            { label: "Sem resposta", data: questao_73[2] },
        ];
    } else if(questao == '#questao74') {
        return [
            { label: "7 anos de idade ou menos", data: questao_74[0] },
            { label: "8 anos", data: questao_74[1] },
            { label: "9 anos", data: questao_74[2] },
            { label: "10 anos", data: questao_74[3] },
            { label: "11 anos", data: questao_74[4] },
            { label: "12 anos", data: questao_74[5] },
            { label: "13 anos", data: questao_74[6] },
            { label: "14 anos", data: questao_74[7] },
            { label: "15 anos", data: questao_74[8] },
            { label: "16 anos", data: questao_74[9] },
            { label: "17 anos", data: questao_74[10] },
            { label: "18 anos ou mais", data: questao_74[11] },
            { label: "Sem resposta", data: questao_74[12] },
        ];
    } else if(questao == '#questao75') {
        return [
            { label: "Nenhum dia nos últimos 30 dias (0 dia)", data: questao_75[0] },
            { label: "1 ou 2 dias nos últimos 30 dias", data: questao_75[1] },
            { label: "3 a 5 dias nos últimos 30 dias", data: questao_75[2] },
            { label: "6 a 9 dias nos últimos 30 dias", data: questao_75[3] },
            { label: "10 a 19 dias nos últimos 30 dias", data: questao_75[4] },
            { label: "20 a 29 dias nos últimos 30 dias", data: questao_75[5] },
            { label: "Todos os dias nos últimos 30 dias", data: questao_75[6] },
            { label: "Sem resposta", data: questao_75[7] },
        ];
    } else if(questao == '#questao76') {
        return [
            { label: "Não fumei cigarros nos últimos 30 dias", data: questao_76[0] },
            { label: "Eu os comprei numa loja ou botequim", data: questao_76[1] },
            { label: "Eu os comprei num vendedor ambulante (camelô)", data: questao_76[2] },
            { label: "Dei dinheiro para alguém comprá-los para mim", data: questao_76[3] },
            { label: "Eu os pedi a alguém", data: questao_76[4] },
            { label: "Eu peguei escondido", data: questao_76[5] },
            { label: "Uma pessoa mais velha me deu", data: questao_76[6] },
            { label: "Eu os consegui de outro modo", data: questao_76[7] },
            { label: "Sem resposta", data: questao_76[8] },
        ];
    } else if(questao == '#questao77') {
        return [
            { label: "Não tentei comprar cigarros nos últimos 30 dias;", data: questao_77[0] },
            { label: "Sim, alguém se recusou a me vender cigarros por causa de minha idade;", data: questao_77[1] },
            { label: "Não, minha idade não me impediu de comprar cigarros.", data: questao_77[2] },
            { label: "Sem resposta", data: questao_77[3] },
        ];
    } else if(questao == '#questao78') {
        return [
            { label: "Não uso outros produtos de tabaco", data: questao_78[0] },
            { label: "Nenhum dia nos últimos 30 dias (0 dia)", data: questao_78[1] },
            { label: "1 ou 2 dias nos últimos 30 dias", data: questao_78[2] },
            { label: "3 a 5 dias nos últimos 30 dias", data: questao_78[3] },
            { label: "6 a 9 dias nos últimos 30 dias", data: questao_78[4] },
            { label: "10 a 19 dias nos últimos 30 dias", data: questao_78[5] },
            { label: "20 a 29 dias nos últimos 30 dias", data: questao_78[6] },
            { label: "Todos os 30 dias nos últimos 30 dias", data: questao_78[7] },
            { label: "Sem resposta", data: questao_78[8] },
        ];
    } else if(questao == '#questao79') {
        return [
            { label: "Não usei nenhum produto do tabaco (os produtos do tabaco estão abaixo relacionados)", data: questao_79[0] },
            { label: "Cigarros de cravo (conhecidos como cigarros de Bali).", data: questao_79[1] },
            { label: "Cigarros enrolados à mão (conhecidos como cigarros de palha ou papel)", data: questao_79[2] },
            { label: "Cigarrilhas", data: questao_79[3] },
            { label: "Charutos, charutos pequenos.", data: questao_79[4] },
            { label: "Fumo para mascar", data: questao_79[5] },
            { label: "Narguilé (cachimbo de água)", data: questao_79[6] },
            { label: "Cigarros indianos (bidis)", data: questao_79[7] },
            { label: "Cigarro eletrônico (e-cigarette)", data: questao_79[8] },
            { label: "Outros", data: questao_79[9] },
            { label: "Sem resposta", data: questao_79[10] },
        ];
    } else if(questao == '#questao80') {
        return [
            { label: "Nenhum dia nos últimos 7 dias (0 dia)", data: questao_80[0] },
            { label: "1 ou 2 dias nos últimos 7 dias", data: questao_80[1] },
            { label: "3 ou 4 dias nos últimos 7 dias", data: questao_80[2] },
            { label: "5 ou 6 dias nos últimos 7 dias", data: questao_80[3] },
            { label: "Todos os 7 dias", data: questao_80[4] },
            { label: "Sem resposta", data: questao_80[5] },
        ];
    } else if(questao == '#questao81') {
        return [
            { label: "Nenhum deles", data: questao_81[0] },
            { label: "Só meu pai ou responsável do sexo masculino", data: questao_81[1] },
            { label: "Só minha mãe ou responsável do sexo feminino", data: questao_81[2] },
            { label: "Meu pai e minha mãe ou responsáveis", data: questao_81[3] },
            { label: "Não sei", data: questao_81[4] },
            { label: "Sem resposta", data: questao_81[5] },
        ];
    } else if(questao == '#questao82') {
        return [
            { label: "Sim", data: questao_82[0] },
            { label: "Não", data: questao_82[1] },
            { label: "Sem resposta", data: questao_82[2] },
        ];
    } else if(questao == '#questao83') {
        return [
            { label: "7 anos de idade ou menos", data: questao_83[0] },
            { label: "8 anos", data: questao_83[1] },
            { label: "9 anos", data: questao_83[2] },
            { label: "10 anos", data: questao_83[3] },
            { label: "11 anos", data: questao_83[4] },
            { label: "12 anos", data: questao_83[5] },
            { label: "13 anos", data: questao_83[6] },
            { label: "14 anos", data: questao_83[7] },
            { label: "15 anos", data: questao_83[8] },
            { label: "16 anos", data: questao_83[9] },
            { label: "17 anos", data: questao_83[10] },
            { label: "18 anos ou mais", data: questao_83[11] },
            { label: "Sem resposta", data: questao_83[12] },
        ];
    } else if(questao == '#questao84') {
        return [
            { label: "Nenhum dia nos últimos 30 dias (0 dia)", data: questao_84[0] },
            { label: "1 ou 2 dias nos últimos 30 dias", data: questao_84[1] },
            { label: "3 a 5 dias nos últimos 30 dias", data: questao_84[2] },
            { label: "6 a 9 dias nos últimos 30 dias", data: questao_84[3] },
            { label: "10 a 19 dias nos últimos 30 dias", data: questao_84[4] },
            { label: "20 a 29 dias nos últimos 30 dias", data: questao_84[5] },
            { label: "Todos os dias nos últimos 30 dias", data: questao_84[6] },
            { label: "Sem resposta", data: questao_84[7] },
        ];
    } else if(questao == '#questao85') {
        return [
            { label: "Não tomei nenhuma bebida alcoólica nos últimos 30 dias (0 dia)", data: questao_85[0] },
            { label: "Menos de um copo ou dose nos últimos 30 dias", data: questao_85[1] },
            { label: "1 copo ou 1 dose nos últimos 30 dias", data: questao_85[2] },
            { label: "2 copos ou 2 doses nos últimos 30 dias", data: questao_85[3] },
            { label: "3 copos ou 3 doses nos últimos 30 dias", data: questao_85[4] },
            { label: "4 copos ou 4 doses nos últimos 30 dias", data: questao_85[5] },
            { label: "5 copos ou mais ou 5 doses ou mais nos últimos 30 dias", data: questao_85[6] },
            { label: "Sem resposta", data: questao_85[7] },
        ];
    } else if(questao == '#questao86') {
        return [
            { label: "Não tomei nenhuma bebida alcoólica nos últimos 30 dias (0 dia)", data: questao_86[0] },
            { label: "Comprei no mercado, loja, bar ou supermercado", data: questao_86[1] },
            { label: "Comprei de um vendedor de rua", data: questao_86[2] },
            { label: "Dei dinheiro a alguém que comprou para mim", data: questao_86[3] },
            { label: "Consegui com meus amigos", data: questao_86[4] },
            { label: "Peguei na minha casa sem permissão", data: questao_86[5] },
            { label: "Consegui com alguém em minha família", data: questao_86[6] },
            { label: "Em uma festa", data: questao_86[7] },
            { label: "Consegui de outro modo", data: questao_86[8] },
            { label: "Sem resposta", data: questao_86[9] },
        ];
    } else if(questao == '#questao87') {
        return [
            { label: "Nenhuma vez na vida (0 vez)", data: questao_87[0] },
            { label: "1 ou 2 vezes na vida", data: questao_87[1] },
            { label: "3 a 5 vezes na vida", data: questao_87[2] },
            { label: "6 a 9 vezes na vida", data: questao_87[3] },
            { label: "10 ou mais vezes na vida", data: questao_87[4] },
            { label: "Sem resposta", data: questao_87[5] },
        ];
    } else if(questao == '#questao88') {
        return [
            { label: "Nenhuma vez na vida (0 vez)", data: questao_88[0] },
            { label: "1 ou 2 vezes na vida", data: questao_88[1] },
            { label: "3 a 5 vezes na vida", data: questao_88[2] },
            { label: "6 a 9 vezes na vida", data: questao_88[3] },
            { label: "10 ou mais vezes na vida", data: questao_88[4] },
            { label: "Sem resposta", data: questao_88[5] },
        ];
    } else if(questao == '#questao89') {
        return [
            { label: "Nenhum", data: questao_89[0] },
            { label: "Poucos", data: questao_89[1] },
            { label: "Alguns", data: questao_89[2] },
            { label: "A maioria", data: questao_89[3] },
            { label: "Todos", data: questao_89[4] },
            { label: "Não sei", data: questao_89[5] },
            { label: "Sem resposta", data: questao_89[6] },
        ];
    } else if(questao == '#questao90') {
        return [
            { label: "Sim", data: questao_90[0] },
            { label: "Não", data: questao_90[1] },
            { label: "Sem resposta", data: questao_90[2] },
        ];
    } else if(questao == '#questao91') {
        return [
            { label: "7 anos ou menos", data: questao_91[0] },
            { label: "8 anos", data: questao_91[1] },
            { label: "9 anos", data: questao_91[2] },
            { label: "10 anos", data: questao_91[3] },
            { label: "11 anos", data: questao_91[4] },
            { label: "12 anos", data: questao_91[5] },
            { label: "13 anos", data: questao_91[6] },
            { label: "14 anos", data: questao_91[7] },
            { label: "15 anos", data: questao_91[8] },
            { label: "16 anos", data: questao_91[9] },
            { label: "17 anos", data: questao_91[10] },
            { label: "18 anos ou mais", data: questao_91[11] },
            { label: "Sem resposta", data: questao_91[12] },
        ];
    } else if(questao == '#questao92') {
        return [
            { label: "Nenhum dia nos últimos 30 dias (0 dia)", data: questao_92[0] },
            { label: "1 ou 2 dias nos últimos 30 dias", data: questao_92[1] },
            { label: "3 a 5 dias nos últimos 30 dias", data: questao_92[2] },
            { label: "6 a 9 dias nos últimos 30 dias", data: questao_92[3] },
            { label: "10 ou mais dias nos últimos 30 dias", data: questao_92[4] },
            { label: "Sem resposta", data: questao_92[5] },
        ];
    } else if(questao == '#questao93') {
        return [
            { label: "Nenhum dia nos últimos 30 dias (0 dia)", data: questao_93[0] },
            { label: "1 ou 2 dias nos últimos 30 dias", data: questao_93[1] },
            { label: "3 a 5 dias nos últimos 30 dias", data: questao_93[2] },
            { label: "6 a 9 dias nos últimos 30 dias", data: questao_93[3] },
            { label: "10 ou mais dias nos últimos 30 dias", data: questao_93[4] },
            { label: "Sem resposta", data: questao_93[5] },
        ];
    } else if(questao == '#questao94') {
        return [
            { label: "Nenhum dia nos últimos 30 dias (0 dia)", data: questao_94[0] },
            { label: "1 ou 2 dias nos últimos 30 dias", data: questao_94[1] },
            { label: "3 a 5 dias nos últimos 30 dias", data: questao_94[2] },
            { label: "6 a 9 dias nos últimos 30 dias", data: questao_94[3] },
            { label: "10 ou mais dias nos últimos 30 dias", data: questao_94[4] },
            { label: "Sem resposta", data: questao_94[5] },
        ];
    } else if(questao == '#questao95') {
        return [
            { label: "Nenhum", data: questao_95[0] },
            { label: "Poucos", data: questao_95[1] },
            { label: "Alguns", data: questao_95[2] },
            { label: "A maioria", data: questao_95[3] },
            { label: "Todos", data: questao_95[4] },
            { label: "Não sei", data: questao_95[5] },
            { label: "Sem resposta", data: questao_95[6] },
        ];
    } else if(questao == '#questao96') {
        return [
            { label: "Nenhum dia nos últimos 30 dias (0 dia)", data: questao_96[0] },
            { label: "1 ou 2 dias nos últimos 30 dias", data: questao_96[1] },
            { label: "3 a 5 dias nos últimos 30 dias", data: questao_96[2] },
            { label: "6 a 9 dias nos últimos 30 dias", data: questao_96[3] },
            { label: "10 ou mais dias nos últimos 30 dias", data: questao_96[4] },
            { label: "Sem resposta", data: questao_96[5] },
        ];
    } else if(questao == '#questao97') {
        return [
            { label: "Nunca", data: questao_97[0] },
            { label: "Raramente", data: questao_97[1] },
            { label: "Às vezes", data: questao_97[2] },
            { label: "Na maior parte do tempo", data: questao_97[3] },
            { label: "Sempre", data: questao_97[4] },
            { label: "Sem resposta", data: questao_97[5] },
        ];
    } else if(questao == '#questao98') {
        return [
            { label: "Nunca", data: questao_98[0] },
            { label: "Raramente", data: questao_98[1] },
            { label: "Às vezes", data: questao_98[2] },
            { label: "Na maior parte do tempo", data: questao_98[3] },
            { label: "Sempre", data: questao_98[4] },
            { label: "Sem resposta", data: questao_98[5] },
        ];
    } else if(questao == '#questao99') {
        return [
            { label: "Nunca", data: questao_99[0] },
            { label: "Raramente", data: questao_99[1] },
            { label: "Às vezes", data: questao_99[2] },
            { label: "Na maior parte do tempo", data: questao_99[3] },
            { label: "Sempre", data: questao_99[4] },
            { label: "Sem resposta", data: questao_99[5] },
        ];
    } else if(questao == '#questao100') {
        return [
            { label: "Nunca", data: questao_100[0] },
            { label: "Raramente", data: questao_100[1] },
            { label: "Às vezes", data: questao_100[2] },
            { label: "Na maior parte do tempo", data: questao_100[3] },
            { label: "Sempre", data: questao_100[4] },
            { label: "Sem resposta", data: questao_100[5] },
        ];
    } else if(questao == '#questao101') {
        return [
            { label: "Nunca", data: questao_101[0] },
            { label: "Raramente", data: questao_101[1] },
            { label: "Às vezes", data: questao_101[2] },
            { label: "Na maior parte do tempo", data: questao_101[3] },
            { label: "Sempre", data: questao_101[4] },
            { label: "Sem resposta", data: questao_101[5] },
        ];
    } else if(questao == '#questao102') {
        return [
            { label: "Nunca", data: questao_102[0] },
            { label: "Raramente", data: questao_102[1] },
            { label: "Às vezes", data: questao_102[2] },
            { label: "Na maior parte do tempo", data: questao_102[3] },
            { label: "Sempre", data: questao_102[4] },
            { label: "Sem resposta", data: questao_102[5] },
        ];
    } else if(questao == '#questao103') {
        return [
            { label: "A minha cor ou raça", data: questao_103[0] },
            { label: "A minha religião", data: questao_103[1] },
            { label: "A aparência do meu rosto", data: questao_103[2] },
            { label: "A aparência do meu corpo", data: questao_103[3] },
            { label: "A minha orientação sexual", data: questao_103[4] },
            { label: "A minha região de origem", data: questao_103[5] },
            { label: "Outros motivos/causas", data: questao_103[6] },
            { label: "Sem resposta", data: questao_103[7] },
        ];
    } else if(questao == '#questao104') {
        return [
            { label: "Sim", data: questao_104[0] },
            { label: "Não", data: questao_104[1] },
            { label: "Sem resposta", data: questao_104[2] },
        ];
    } else if(questao == '#questao105') {
        return [
            { label: "Sim", data: questao_105[0] },
            { label: "Não", data: questao_105[1] },
            { label: "Não sei o que é bullying", data: questao_105[2] },
            { label: "Sempre", data: questao_105[3] },
            { label: "Sem resposta", data: questao_105[4] },
        ];
    } else if(questao == '#questao106') {
        return [
            { label: "Nunca", data: questao_106[0] },
            { label: "Raramente", data: questao_106[1] },
            { label: "Às vezes", data: questao_106[2] },
            { label: "Na maioria das vezes", data: questao_106[3] },
            { label: "Sempre", data: questao_106[4] },
            { label: "Sem resposta", data: questao_106[5] },
        ];
    } else if(questao == '#questao107') {
        return [
            { label: "Nenhum amigo (0)", data: questao_107[0] },
            { label: "1 amigo", data: questao_107[1] },
            { label: "2 amigos", data: questao_107[2] },
            { label: "3 ou mais amigos", data: questao_107[3] },
            { label: "Sem resposta", data: questao_107[4] },
        ];
    } else if(questao == '#questao108') {
        return [
            { label: "Nunca", data: questao_108[0] },
            { label: "Raramente", data: questao_108[1] },
            { label: "Às vezes", data: questao_108[2] },
            { label: "Na maioria das vezes", data: questao_108[3] },
            { label: "Sempre", data: questao_108[4] },
            { label: "Sem resposta", data: questao_108[5] },
        ];
    } else if(questao == '#questao109') {
        return [
            { label: "Nunca", data: questao_109[0] },
            { label: "Raramente", data: questao_109[1] },
            { label: "Às vezes", data: questao_109[2] },
            { label: "Na maioria das vezes", data: questao_109[3] },
            { label: "Sempre", data: questao_109[4] },
            { label: "Sem resposta", data: questao_109[5] },
        ];
    } else if(questao == '#questao110') {
        return [
            { label: "Nunca", data: questao_110[0] },
            { label: "Raramente", data: questao_110[1] },
            { label: "Às vezes", data: questao_110[2] },
            { label: "Na maioria das vezes", data: questao_110[3] },
            { label: "Sempre", data: questao_110[4] },
            { label: "Sem resposta", data: questao_110[5] },
        ];
    } else if(questao == '#questao111') {
        return [
            { label: "Não escovei meus dentes nos últimos 30 dias", data: questao_111[0] },
            { label: "Não escovei meus dentes diariamente", data: questao_111[1] },
            { label: "1 vez por dia nos últimos 30 dias", data: questao_111[2] },
            { label: "2 vezes por dia nos últimos 30 dias", data: questao_111[3] },
            { label: "3 vezes por dia nos últimos 30 dias", data: questao_111[4] },
            { label: "4 ou mais vezes por dia nos últimos 30 dias", data: questao_111[5] },
            { label: "Sem resposta", data: questao_111[6] },
        ];
    } else if(questao == '#questao112') {
        return [
            { label: "Sim", data: questao_112[0] },
            { label: "Não", data: questao_112[1] },
            { label: "Não sei / não me lembro", data: questao_112[2] },
            { label: "Sem resposta", data: questao_112[3] },
        ];
    } else if(questao == '#questao113') {
        return [
            { label: "Nenhuma vez nos últimos 12 meses (0 vez)", data: questao_113[0] },
            { label: "1 vez nos últimos 12 meses", data: questao_113[1] },
            { label: "2 vezes nos últimos 12 meses", data: questao_113[2] },
            { label: "3 ou mais vezes nos últimos 12 meses", data: questao_113[3] },
            { label: "Sem resposta", data: questao_113[4] },
        ];
    } else if(questao == '#questao114') {
        return [
            { label: "Nenhum dia nos últimos 30 dias (0 dia)", data: questao_114[0] },
            { label: "1 dia nos últimos 30 dias", data: questao_114[1] },
            { label: "2 dias nos últimos 30 dias", data: questao_114[2] },
            { label: "3 dias nos últimos 30 dias", data: questao_114[3] },
            { label: "4 dias nos últimos 30 dias", data: questao_114[4] },
            { label: "5 dias ou mais nos últimos 30 dias", data: questao_114[5] },
            { label: "Sem resposta", data: questao_114[6] },
        ];
    } else if(questao == '#questao115') {
        return [
            { label: "Nenhum dia nos últimos 30 dias (0 dia)", data: questao_115[0] },
            { label: "1 dia nos últimos 30 dias", data: questao_115[1] },
            { label: "2 dias nos últimos 30 dias", data: questao_115[2] },
            { label: "3 dias nos últimos 30 dias", data: questao_115[3] },
            { label: "4 dias nos últimos 30 dias", data: questao_115[4] },
            { label: "5 dias ou mais nos últimos 30 dias", data: questao_115[5] },
            { label: "Sem resposta", data: questao_115[6] },
        ];
    } else if(questao == '#questao116') {
        return [
            { label: "Não andei nesse tipo de veículo no banco da frente nos últimos 30 dias", data: questao_116[0] },
            { label: "Nunca uso cinto de segurança", data: questao_116[1] },
            { label: "Raramente", data: questao_116[2] },
            { label: "Às vezes", data: questao_116[3] },
            { label: "Na maior parte do tempo", data: questao_116[4] },
            { label: "Sempre", data: questao_116[5] },
            { label: "Sem resposta", data: questao_116[6] },
        ];
    } else if(questao == '#questao117') {
        return [
            { label: "Não andei de motocicleta nos últimos 30 dias.", data: questao_117[0] },
            { label: "Nunca uso capacete", data: questao_117[1] },
            { label: "Raramente", data: questao_117[2] },
            { label: "Às vezes", data: questao_117[3] },
            { label: "Na maior parte do tempo", data: questao_117[4] },
            { label: "Sempre", data: questao_117[5] },
            { label: "Sem resposta", data: questao_117[6] },
        ];
    } else if(questao == '#questao118') {
        return [
            { label: "Nenhuma vez nos últimos 30 dias (0 vez)", data: questao_118[0] },
            { label: "1 vez nos últimos 30 dias", data: questao_118[1] },
            { label: "2 ou 3 vezes nos últimos 30 dias", data: questao_118[2] },
            { label: "4 ou 5 vezes nos últimos 30 dias", data: questao_118[3] },
            { label: "6 ou mais vezes nos últimos 30 dias", data: questao_118[4] },
            { label: "Sem resposta", data: questao_118[5] },
        ];
    } else if(questao == '#questao119') {
        return [
            { label: "Nenhuma vez nos últimos 30 dias (0 vez)", data: questao_119[0] },
            { label: "1 vez nos últimos 30 dias", data: questao_119[1] },
            { label: "2 ou 3 vezes nos últimos 30 dias", data: questao_119[2] },
            { label: "4 ou 5 vezes nos últimos 30 dias", data: questao_119[3] },
            { label: "6 ou mais vezes nos últimos 30 dias", data: questao_119[4] },
            { label: "Sem resposta", data: questao_119[5] },
        ];
    } else if(questao == '#questao120') {
        return [
            { label: "Nenhuma vez nos últimos 30 dias (0 vez)", data: questao_120[0] },
            { label: "1 vez nos últimos 30 dias", data: questao_120[1] },
            { label: "2 ou 3 vezes nos últimos 30 dias", data: questao_120[2] },
            { label: "4 ou 5 vezes nos últimos 30 dias", data: questao_120[3] },
            { label: "6 ou 7 vezes nos últimos 30 dias", data: questao_120[4] },
            { label: "8 ou 9 vezes nos últimos 30 dias", data: questao_120[5] },
            { label: "10 ou 11 vezes nos últimos 30 dias", data: questao_120[6] },
            { label: "12 vezes ou mais nos últimos 30 dias", data: questao_120[7] },
            { label: "Sem resposta", data: questao_120[8] },
        ];
    } else if(questao == '#questao121') {
        return [
            { label: "Sim", data: questao_121[0] },
            { label: "Não", data: questao_121[1] },
            { label: "Sem resposta", data: questao_121[2] },
        ];
    } else if(questao == '#questao122') {
        return [
            { label: "Sim", data: questao_122[0] },
            { label: "Não", data: questao_122[1] },
            { label: "Sem resposta", data: questao_122[2] },
        ];
    } else if(questao == '#questao123') {
        return [
            { label: "Nenhuma vez nos últimos 12 meses (0 vez)", data: questao_123[0] },
            { label: "1 vez nos últimos 12 meses", data: questao_123[1] },
            { label: "2 a 3 vezes nos últimos 12 meses", data: questao_123[2] },
            { label: "4 a 5 vezes nos últimos 12 meses", data: questao_123[3] },
            { label: "6 a 7 vezes nos últimos 12 meses", data: questao_123[4] },
            { label: "8 a 9 vezes nos últimos 12 meses", data: questao_123[5] },
            { label: "10 a 11 vezes nos últimos 12 meses", data: questao_123[6] },
            { label: "12 ou mais vezes nos últimos 12 meses", data: questao_123[7] },
            { label: "Sem resposta", data: questao_123[8] },
        ];
    } else if(questao == '#questao124') {
        return [
            { label: "Nenhuma vez nos últimos 12 meses (0 vez)", data: questao_124[0] },
            { label: "1 vez nos últimos 12 meses", data: questao_124[1] },
            { label: "2 a 3 vezes nos últimos 12 meses", data: questao_124[2] },
            { label: "4 a 5 vezes nos últimos 12 meses", data: questao_124[3] },
            { label: "6 a 7 vezes nos últimos 12 meses", data: questao_124[4] },
            { label: "8 a 9 vezes nos últimos 12 meses", data: questao_124[5] },
            { label: "10 a 11 vezes nos últimos 12 meses", data: questao_124[6] },
            { label: "12 ou mais vezes nos últimos 12 meses", data: questao_124[7] },
            { label: "Sem resposta", data: questao_124[8] },
        ];
    } else if(questao == '#questao125') {
        return [
            { label: "Nenhuma vez nos últimos 12 meses (0 vez)", data: questao_125[0] },
            { label: "1 vez nos últimos 12 meses", data: questao_125[1] },
            { label: "2 a 3 vezes nos últimos 12 meses", data: questao_125[2] },
            { label: "4 a 5 vezes nos últimos 12 meses", data: questao_125[3] },
            { label: "6 a 7 vezes nos últimos 12 meses", data: questao_125[4] },
            { label: "8 a 9 vezes nos últimos 12 meses", data: questao_125[5] },
            { label: "10 a 11 vezes nos últimos 12 meses", data: questao_125[6] },
            { label: "12 ou mais vezes nos últimos 12 meses", data: questao_125[7] },
            { label: "Sem resposta", data: questao_125[8] },
        ];
    } else if(questao == '#questao126') {
        return [
            { label: "Não tive ferimento/lesão séria nos últimos 12 meses", data: questao_126[0] },
            { label: "Tive um osso quebrado ou junta deslocada", data: questao_126[1] },
            { label: "Tive um corte ou perfuração", data: questao_126[2] },
            { label: "Tive um traumatismo ou outra lesão na cabeça ou pescoço e desmaiei ou não consegui respirar", data: questao_126[3] },
            { label: "Tive um ferimento à bala (arma de fogo)", data: questao_126[4] },
            { label: "Tive uma queimadura grave", data: questao_126[5] },
            { label: "Fui envenenado(a) ou tive overdose (consumi drogas em excesso)", data: questao_126[6] },
            { label: "Tive outra lesão ou machucado", data: questao_126[7] },
            { label: "Sem resposta", data: questao_126[8] },
        ];
    } else if(questao == '#questao127') {
        return [
            { label: "Foi um acidente ou atropelamento causado por veículo motorizado", data: questao_127[0] },
            { label: "Foi algo que caiu sobre mim ou me atingiu", data: questao_127[1] },
            { label: "Foi um ataque que sofri ou briga com alguém (com ou sem uso de arma)", data: questao_127[2] },
            { label: "Foi um incêndio ou a proximidade com algo quente", data: questao_127[3] },
            { label: "Foi a inalação ou algo que engoli e me fez mal", data: questao_127[4] },
            { label: "Foi praticando alguma atividade física/exercício/esporte", data: questao_127[5] },
            { label: "Foi um acidente que sofri quando estava trabalhando", data: questao_127[6] },
            { label: "Foi um acidente enquanto andava de bicicleta", data: questao_127[7] },
            { label: "Foi uma queda", data: questao_127[8] },
            { label: "Foi outra causa", data: questao_127[9] },
            { label: "Sem resposta", data: questao_127[10] },
        ];
    } else if(questao == '#questao128') {
        return [
            { label: "Não andei de bicicleta nos últimos 12 meses", data: questao_128[0] },
            { label: "Andei de bicicleta e não sofri acidente", data: questao_128[1] },
            { label: "Andei de bicicleta e sofri acidente", data: questao_128[2] },
            { label: "Sem resposta", data: questao_128[3] },
        ];
    } else if(questao == '#questao129') {
        return [
            { label: "Sim", data: questao_129[0] },
            { label: "Não", data: questao_129[1] },
            { label: "Sem resposta", data: questao_129[2] },
        ];
    } else if(questao == '#questao130') {
        return [
            { label: "Namorado(a)/ex-namorado(a)", data: questao_130[0] },
            { label: "Amigo(a)", data: questao_130[1] },
            { label: "Pai/mãe/padrasto/madrasta", data: questao_130[2] },
            { label: "Outros familiares", data: questao_130[3] },
            { label: "Desconhecido(a)", data: questao_130[4] },
            { label: "Outro (as)", data: questao_130[5] },
            { label: "Sem resposta", data: questao_130[6] },
        ];
    } else if(questao == '#questao131') {
        return [
            { label: "Muito bom", data: questao_131[0] },
            { label: "Bom", data: questao_131[1] },
            { label: "Regular", data: questao_131[2] },
            { label: "Ruim", data: questao_131[3] },
            { label: "Muito ruim", data: questao_131[4] },
            { label: "Sem resposta", data: questao_131[5] },
        ];
    } else if(questao == '#questao132') {
        return [
            { label: "Não faltei a escola nos últimos 12 meses por motivos de saúde", data: questao_132[0] },
            { label: "1 a 3 dias nos últimos 12 meses", data: questao_132[1] },
            { label: "4 a 7 dias nos últimos 12 meses", data: questao_132[2] },
            { label: "8 a 15 dias nos últimos 12 meses", data: questao_132[3] },
            { label: "16 dias ou mais nos últimos 12 meses", data: questao_132[4] },
            { label: "Sem resposta", data: questao_132[5] },
        ];
    } else if(questao == '#questao133') {
        return [
            { label: "Sim", data: questao_133[0] },
            { label: "Não", data: questao_133[1] },
            { label: "Sem resposta", data: questao_133[2] },
        ];
    } else if(questao == '#questao134') {
        return [
            { label: "Unidade Básica de Saúde (Centro ou Posto de saúde ou Unidade de Saúde da Família/PSF)", data: questao_134[0] },
            { label: "Consultório médico particular ou clínica particular", data: questao_134[1] },
            { label: "Consultório odontológico", data: questao_134[2] },
            { label: "Consultório de outro profissional de saúde (fonoaudiólogo, psicólogo etc.)", data: questao_134[3] },
            { label: "Serviço de especialidades médicas ou Policlínica", data: questao_134[4] },
            { label: "Pronto-socorro, emergência ou UPA", data: questao_134[5] },
            { label: "Hospital", data: questao_134[6] },
            { label: "Laboratório ou clínica para exames complementares", data: questao_134[7] },
            { label: "Serviço de atendimento domiciliar", data: questao_134[8] },
            { label: "Farmácia", data: questao_134[9] },
            { label: "Outro", data: questao_134[10] },
            { label: "Sem resposta", data: questao_134[11] },
        ];
    } else if(questao == '#questao135') {
        return [
            { label: "Sim", data: questao_135[0] },
            { label: "Não", data: questao_135[1] },
            { label: "Não procurei uma Unidade Básica de Saúde", data: questao_135[2] },
            { label: "Sem resposta", data: questao_135[3] },
        ];
    } else if(questao == '#questao136') {
        return [
            { label: "Apoio para controle de peso (ganhar ou perder)", data: questao_136[0] },
            { label: "Apoio para parar de fumar", data: questao_136[1] },
            { label: "Acidente ou lesão", data: questao_136[2] },
            { label: "Reabilitação ou terapia", data: questao_136[3] },
            { label: "Doença", data: questao_136[4] },
            { label: "Problema odontológico", data: questao_136[5] },
            { label: "Vacinação", data: questao_136[6] },
            { label: "Consulta para métodos contraceptivos (preservativos, pílula, DIU etc.)", data: questao_136[7] },
            { label: "Buscar contracepção de emergência (pílula do dia seguinte)", data: questao_136[8] },
            { label: "Teste para HIV, Sífilis ou Hepatite B", data: questao_136[9] },
            { label: "Pré-natal / Teste para gravidez", data: questao_136[10] },
            { label: "Solicitação de atestado médico", data: questao_136[11] },
            { label: "Outro", data: questao_136[12] },
            { label: "Sem resposta", data: questao_136[13] },
        ];
    } else if(questao == '#questao137') {
        return [
            { label: "Sim", data: questao_137[0] },
            { label: "Não", data: questao_137[1] },
            { label: "Sem resposta", data: questao_137[2] },
        ];
    } else if(questao == '#questao138') {
        return [
            { label: "Sim", data: questao_138[0] },
            { label: "Não", data: questao_138[1] },
            { label: "Sem resposta", data: questao_138[2] },
        ];
    } else if(questao == '#questao139') {
        return [
            { label: "Muito importante", data: questao_139[0] },
            { label: "Importante", data: questao_139[1] },
            { label: "Pouco importante", data: questao_139[2] },
            { label: "Sem importância", data: questao_139[3] },
            { label: "Sem resposta", data: questao_139[4] },
        ];
    } else if(questao == '#questao140') {
        return [
            { label: "Muito satisfeito(a)", data: questao_140[0] },
            { label: "Satisfeito(a)", data: questao_140[1] },
            { label: "Indiferente", data: questao_140[2] },
            { label: "Insatisfeito(a)", data: questao_140[3] },
            { label: "Muito insatisfeito(a)", data: questao_140[4] },
            { label: "Sem resposta", data: questao_140[5] },
        ];
    } else if(questao == '#questao141') {
        return [
            { label: "Muito magro(a)", data: questao_141[0] },
            { label: "Magro(a)", data: questao_141[1] },
            { label: "Normal", data: questao_141[2] },
            { label: "Gordo(a)", data: questao_141[3] },
            { label: "Muito Gordo(a)", data: questao_141[4] },
            { label: "Sem resposta", data: questao_141[5] },
        ];
    } else if(questao == '#questao142') {
        return [
            { label: "Não estou fazendo nada", data: questao_142[0] },
            { label: "Estou tentando perder peso", data: questao_142[1] },
            { label: "Estou tentando ganhar peso", data: questao_142[2] },
            { label: "Estou tentando manter o mesmo peso", data: questao_142[3] },
            { label: "Sem resposta", data: questao_142[4] },
        ];
    } else if(questao == '#questao143') {
        return [
            { label: "Sim", data: questao_143[0] },
            { label: "Não", data: questao_143[1] },
            { label: "Sem resposta", data: questao_143[2] },
        ];
    } else if(questao == '#questao144') {
        return [
            { label: "Sim", data: questao_144[0] },
            { label: "Não", data: questao_144[1] },
            { label: "Sem resposta", data: questao_144[2] },
        ];
    } else if(questao == '#questao145') {
        return [
            { label: "Sim", data: questao_145[0] },
            { label: "Não", data: questao_145[1] },
            { label: "Sem resposta", data: questao_145[2] },
        ];
    } else if(questao == '#questao146') {
        return [
            { label: "Fácil", data: questao_146[0] },
            { label: "Difícil", data: questao_146[1] },
            { label: "Chato", data: questao_146[2] },
            { label: "Legal", data: questao_146[3] },
            { label: "Interessante", data: questao_146[4] },
            { label: "Informativo", data: questao_146[5] },
            { label: "Cansativo", data: questao_146[6] },
            { label: "Constrangedor", data: questao_146[7] },
            { label: "Sem resposta", data: questao_146[8] },
        ];
    }
}

document.getElementById("baixa-grafico-1").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao1')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-2").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao2')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-3").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao3')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-4").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao4')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-5").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao5')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-6").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao6')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-7").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao7')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-8").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao8')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-9").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao9')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-10").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao10')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-11").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao11')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-12").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao12')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-13").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao13')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-14").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao14')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-15").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao15')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-16").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao16')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-17").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao17')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-18").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao18')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-19").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao19')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-20").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao20')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-21").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao21')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-22").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao22')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-23").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao23')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-24").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao24')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-25").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao25')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-26").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao26')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-27").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao27')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-28").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao28')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-29").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao29')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-30").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao30')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-31").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao31')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-32").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao32')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-33").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao33')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-34").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao34')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-35").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao35')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-36").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao36')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-37").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao37')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-38").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao38')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-39").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao39')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-40").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao40')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-41").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao41')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-42").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao42')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-43").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao43')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-44").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao44')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-45").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao45')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-46").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao46')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-47").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao47')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-48").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao48')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-49").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao49')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-50").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao50')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-51").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao51')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-52").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao52')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-53").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao53')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-54").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao54')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-55").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao55')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-56").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao56')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-57").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao57')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-58").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao58')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-59").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao59')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-60").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao60')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-61").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao61')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-62").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao62')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-63").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao63')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-64").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao64')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-65").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao65')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-66").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao66')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-67").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao67')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-68").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao68')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-69").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao69')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-70").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao70')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-71").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao71')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-72").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao72')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-73").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao73')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-74").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao74')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-75").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao75')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-76").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao76')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-77").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao77')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-78").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao78')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-79").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao79')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-80").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao80')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-81").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao81')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-82").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao82')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-83").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao83')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-84").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao84')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-85").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao85')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-86").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao86')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-87").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao87')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-88").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao88')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-89").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao89')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-90").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao90')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-91").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao91')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-92").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao92')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-93").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao93')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-94").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao94')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-95").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao95')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-96").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao96')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-97").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao97')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-98").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao98')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-99").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao99')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-100").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao100')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-101").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao101')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-102").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao102')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-103").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao103')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-104").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao104')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-105").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao105')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-106").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao106')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-107").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao107')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-108").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao108')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-109").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao109')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-110").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao110')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-111").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao111')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-112").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao112')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-113").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao113')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-114").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao114')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-115").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao115')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-116").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao116')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-117").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao117')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-118").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao118')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-119").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao119')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-120").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao120')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-121").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao121')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-122").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao122')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-123").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao123')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-124").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao124')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-125").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao125')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-126").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao126')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-127").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao127')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-128").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao128')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-129").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao129')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-130").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao130')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-131").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao131')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-132").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao132')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-133").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao133')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-134").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao134')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-135").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao135')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-136").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao136')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-137").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao137')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-138").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao138')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-139").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao139')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-140").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao140')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-141").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao141')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-142").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao142')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-143").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao143')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-144").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao144')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-145").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao145')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

document.getElementById("baixa-grafico-146").addEventListener("click", function() {
    html2canvas(document.querySelector('#questao146')).then(function(canvas) {
        console.log(canvas);
        baixaImagem(canvas.toDataURL(), 'grafico.png');
    });
});

function baixaImagem(uri, filename) {
    var link = document.createElement('a');
    
    if (typeof link.download === 'string') {
        link.href = uri;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    } else {
        window.open(uri);
    }
}
