/* Muda a cor da navbar quando houver scroll do mouse */

/*
$(function () {
  $(document).scroll(function () {
    var $nav = $(".navbar");
    $nav.toggleClass('white-nav', $(this).scrollTop() > $nav.height());
    $nav.toggleClass('border-bottom', $(this).scrollTop() > $nav.height());
    
    var $link = $(".nav-link");
    $link.toggleClass('black-link', $(this).scrollTop() > $link.height());
    
    $link.toggleClass('white-link', $(this).scrollTop() < $link.height());
    $link.removeClass('white-link', $(this).scrollTop() > $link.eight());
  });
});
*/
